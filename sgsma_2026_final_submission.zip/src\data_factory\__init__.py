"""Scenario and topology utilities for the SGSMA synthetic data factory."""
