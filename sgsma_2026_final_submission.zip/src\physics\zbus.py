﻿"""Phase-1 scaffold module for zbus."""

# TODO(phase-2): migrate legacy implementation with parity tests.
