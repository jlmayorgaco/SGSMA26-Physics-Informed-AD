# SGSMA 2026 Physics-Informed Anomaly Detection

This repository contains the final SGSMA 2026 submission workflow for anomaly detection on IEEE 39-bus synchrophasor datasets.

## Reviewer Entry Point

Run bus-agnostic inference from the repository root:

```powershell
python main.py --input-dir data\RAW0001
```

If `--input-dir` is omitted, `main.py` reads `data\RAW0001`. By default it writes:

```text
<input-dir>\predictions.csv
<input-dir>\prediction_diagnostics.json
```

`main.py` detects all `Bus*.csv` files in the input folder. It does not require
the fixed RAW001 PMU bus set; bus IDs are parsed from filenames and used as
metadata for bus-agnostic physics/ranking inference.

## What Is Included

- `models/`: frozen model bundle split into `detector/`, `classifiers/`, and `localizer/`.
- `models_bus_agnostic/`: default reviewer-facing bus-agnostic model/config bundle used by `main.py`.
- `src/data_factory/`: feature extraction, training, evaluation, and inference code.
- `pipelines/`: ordered entry points for rebuilding the workflow.
- `data/metadata/` and `data/topology/`: network metadata, Ybus/Zbus, and competition mapping files.
- `report/ieee_method_report/`: paper source, plots, tables, and compiled PDF.
- `overview.md`: engineering summary of the selected method and rejected alternatives.
- `REPRODUCIBILITY.md`: exact rebuild instructions.
- `notebooks/SGSMA_v2_localizer_workflow.ipynb`: step-by-step RAW/SIM evaluation and candidate-ranker localizer workflow.

The RAW001 PMU CSV files live in `data/RAW0001/` for local reproduction. They are not packed into the final submission zip.

## Model

The reviewer-facing submitted model is `bus_agnostic_physics_v1`.

It has three inference layers:

1. Per-PMU robust feature extraction without fixed BUS-prefixed feature names.
2. Order-invariant global aggregation across whatever PMUs are present.
3. IEEE-39 topology-aware location ranking over bus, line, and PMU candidates.

The legacy fixed-PMU experimental model is `base_v2 + rolling + rls_kalman + graph_temporal`.

It has three stages:

1. `models/detector/`: event0 versus non-event0 routing plus missing/bad-data branches.
2. `models/classifiers/`: physical event classifier for labels 0 through 8.
3. `models/localizer/`: typed BUS, LINE, and PMU localizers.

The bundle also includes a conservative physics-informed hybrid localizer for
Top-K analysis. By default, `predict_from_features()` keeps the validated typed
ML Top-1 localizer; set `use_hybrid_top1` in `models/final_model_config.json`
only after a full P1-P5 rebuild verifies that the hybrid re-ranker improves SIM
validation without degrading transfer performance.

Use the legacy public wrapper only when fixed-PMU feature tables are already extracted:

```python
from src.data_factory.final_model import load_final_model

model = load_final_model()
predictions = model.predict_from_features(base_features, dynamic_features)
```

## Metrics

| Dataset | Detector | Classifier | Exact localizer |
| --- | ---: | ---: | ---: |
| RAW001 | 100.00% | 100.00% | 66.67% |
| Synthetic holdout | 96.93% | 96.73% | 85.24% |

## Rebuild

Install the Python dependencies:

```powershell
python -m pip install -r requirements.txt
```

Run the full final-quality workflow:

```powershell
python pipelines\run_all.py --n 5000 --workers 8
```

For a shorter clean-start check:

```powershell
python pipelines\run_all.py --n 1000 --workers 8 --no-compile --no-zip
```

See `REPRODUCIBILITY.md` for the stage-by-stage details.
