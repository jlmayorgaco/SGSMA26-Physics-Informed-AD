# Reproducible Workflow

This repository can run the final bus-agnostic SGSMA 2026 inference workflow on any IEEE-39 folder of `Bus*.csv` PMU files. It can also regenerate the legacy fixed-PMU experimental workflow from the tracked IEEE 39 metadata and the RAW001 PMU CSV files.

## Reviewer Inference

```powershell
python main.py --input-dir data\RAW0001
```

Default behavior:

- input: all `Bus*.csv` files under `--input-dir`
- output: `<input-dir>\predictions.csv`
- diagnostics: `<input-dir>\prediction_diagnostics.json`

The output CSV uses the required separate-file schema:

```text
TIMESTAMP, Bus, Predicted_Event, Predicted_Location
```

The reviewer-facing route is bus-agnostic. It parses bus IDs from filenames and
does not require the RAW001 PMU set `2,5,6,10,19,22,29,39`.

## Inputs

Required files:

- `data/RAW0001/Bus*_Competition_Data_nanmask.csv`
- `data/metadata/IEEE_39_Bus_Power_System.raw`
- `data/metadata/ieee39_competition_contract.json`
- `data/metadata/Event Timeline & Location.xlsx`
- `data/metadata/PMUbus_ Location.txt`

The final submission zip does not include `data/RAW0001` because it is large. Keep those eight RAW001 PMU CSV files in that folder before running the full pipeline.

## Environment

```powershell
python -m venv .venv
.\.venv\Scripts\python -m pip install --upgrade pip
.\.venv\Scripts\python -m pip install -r requirements.txt
```

Optional report compilation requires a LaTeX distribution with `pdflatex` and `bibtex` on `PATH`.

## Legacy Fixed-PMU Rebuild

```powershell
python pipelines\run_all.py --n 5000 --workers 8
```

This executes the legacy fixed-PMU workflow:

1. `p0_tuning_simulator.py`: rebuilds Ybus/Zbus topology, RAW001 event windows, and the RAWANDES-PMU simulator profile.
2. `p1_generate_simulation.py`: generates scenarios and simulated PMU plus hidden-bus CSV files.
3. `p2_extract_features.py`: extracts V2 statistical features, V3 dynamic features, and RAW001 dynamic features.
4. `p3_train_detector.py`: trains the event0 versus non-event0 detector.
5. `p4_train_classifier.py`: trains/reports the event classifier.
6. `p5_train_localizer.py`: trains the dynamic typed localizer with `rolling,rls_kalman,graph_temporal` features.
7. `p6_generate_report.py`: compiles the report and packages submission artifacts.

Generated files are written under `workbench/` and are ignored by Git.

For a faster functional smoke test, use:

```powershell
python pipelines\run_all.py --n 1000 --workers 8 --no-compile --no-zip
```

The 1000-scenario run validates that the legacy workflow is executable from clean generated state. The legacy frozen metrics were selected from the 5000-scenario training campaign.

## Stage Commands

```powershell
python pipelines\p0_tuning_simulator.py --force-timeline
python pipelines\p1_generate_simulation.py --n 5000 --workers 8 --plots
python pipelines\p2_extract_features.py --workers 8 --force
python pipelines\p3_train_detector.py --feature-workers 8
python pipelines\p4_train_classifier.py
python pipelines\p5_train_localizer.py --fail-if-missing
python pipelines\p6_generate_report.py
```

Use `--no-compile --no-zip` in `p6_generate_report.py` when LaTeX is not installed and only the metric summary is needed.

## Model Bundles

The default bus-agnostic model/config bundle is:

```text
models_bus_agnostic/
```

The legacy fixed-PMU bundle is:

```text
models/
  detector/
  classifiers/
  localizer/
```

The legacy bundle can be loaded without rerunning training:

```python
from src.data_factory.final_model import load_final_model

model = load_final_model()
```

## Simulator Note

The active submission path uses `RAWANDES-PMU`, a RAW-profiled fast topology surrogate built from RAW001 operating windows plus IEEE 39 Ybus/Zbus propagation. Earlier full ANDES calibration experiments informed the feature design, but the final reproducible pipeline does not require the external ANDES package.
