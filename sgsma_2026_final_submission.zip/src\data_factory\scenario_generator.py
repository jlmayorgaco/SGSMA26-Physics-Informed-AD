from __future__ import annotations

import argparse
import json
import random
import sys
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any

import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
root_text = str(ROOT)
if root_text not in sys.path:
    sys.path.insert(0, root_text)

from src.helpers.power_network import _parse_branch_section_physical
from src.utils.io import json_safe as _shared_json_safe


DEFAULT_RAW = ROOT / "data" / "metadata" / "IEEE_39_Bus_Power_System.raw"
DEFAULT_CONTRACT = ROOT / "data" / "metadata" / "ieee39_competition_contract.json"
DEFAULT_OUT = ROOT / "data" / "scenarios" / "sgsma_2026_v1"
DEFAULT_CASE_REPORT = (
    ROOT
    / "data"
    / "simulated"
    / "RAWANDES_EVENT1_BUS39_ANGLE_SWEEP"
    / "rawandes_event1_angle_param_sweep_report.json"
)

OBSERVED_PMUS = (2, 5, 6, 10, 19, 22, 29, 39)
GENERATOR_BUSES = tuple(range(30, 40))
FALLBACK_LOAD_BUSES = (3, 4, 7, 8, 12, 15, 16, 18, 20, 21, 23, 24, 25, 26, 27, 28, 29)
RAW_LOCALIZER_FOCUS_BUSES = (2, 7, 12, 23, 24, 38)
RAW_LOCALIZER_FOCUS_LINES = ((23, 24), (22, 35), (2, 30))


@dataclass(frozen=True, slots=True)
class ScenarioEvent:
    type: str
    t_start: float
    duration: float | None = None
    bus_target: int | None = None
    line_target: str | None = None
    line_from: int | None = None
    line_to: int | None = None
    amount: float | None = None
    pmu_target: int | None = None
    signal_target: str | None = None
    severity: float | None = None


@dataclass(frozen=True, slots=True)
class Scenario:
    sim_id: str
    schema_version: str
    random_seed: int
    duration_s: float
    dt_s: float
    observed_pmus: tuple[int, ...]
    sequence: tuple[str, ...]
    events: tuple[ScenarioEvent, ...]
    labels: dict[str, Any]
    raw_profile: dict[str, Any]
    notes: str


def _json_safe(value: Any) -> Any:
    return _shared_json_safe(value)


def _load_contract(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))


def _calibrated_case_path() -> Path | None:
    if not DEFAULT_CASE_REPORT.exists():
        return None
    report = json.loads(DEFAULT_CASE_REPORT.read_text(encoding="utf-8"))
    case = Path(report["best"]["manifest"]["base_case"])
    return case if case.exists() else None


def _load_buses_from_case(sheet: str, column: str = "bus") -> tuple[int, ...]:
    case = _calibrated_case_path()
    if case is None:
        return tuple()
    try:
        frame = pd.read_excel(case, sheet_name=sheet)
    except Exception:
        return tuple()
    if column not in frame:
        return tuple()
    values = pd.to_numeric(frame[column], errors="coerce").dropna().astype(int).tolist()
    return tuple(dict.fromkeys(values))


def _generator_buses_from_case() -> tuple[int, ...]:
    buses = list(_load_buses_from_case("PV"))
    buses.extend(_load_buses_from_case("Slack"))
    return tuple(dict.fromkeys(int(bus) for bus in buses))


def _line_targets(raw_path: Path, max_lines: int = 34) -> list[dict[str, Any]]:
    branches = _parse_branch_section_physical(raw_path)
    unique: list[dict[str, Any]] = []
    seen: set[tuple[int, int]] = set()
    for idx, branch in enumerate(branches, start=1):
        key = tuple(sorted((int(branch.from_bus), int(branch.to_bus))))
        if key in seen:
            continue
        seen.add(key)
        unique.append(
            {
                "line_target": f"Line_{idx}",
                "line_from": int(branch.from_bus),
                "line_to": int(branch.to_bus),
                "r": float(branch.resistance),
                "x": float(branch.reactance),
            }
        )
        if len(unique) >= max_lines:
            break
    return unique


def _event1(bus: int, t: float, rng: random.Random) -> ScenarioEvent:
    return ScenarioEvent(type="event1", bus_target=bus, t_start=t, duration=round(rng.uniform(0.08, 0.20), 3))


def _event2(line: dict[str, Any], t: float) -> ScenarioEvent:
    return ScenarioEvent(
        type="event2",
        line_target=str(line["line_target"]),
        line_from=int(line["line_from"]),
        line_to=int(line["line_to"]),
        t_start=t,
        duration=None,
    )


def _event3(bus: int, t: float, rng: random.Random) -> ScenarioEvent:
    amount = rng.choice([-1.0, 1.0]) * round(rng.uniform(0.04, 0.18), 3)
    return ScenarioEvent(type="event3", bus_target=bus, t_start=t, amount=amount)


def _event4(bus: int, t: float, rng: random.Random) -> ScenarioEvent:
    amount = rng.choice([-1.0, 1.0]) * round(rng.uniform(0.05, 0.25), 3)
    return ScenarioEvent(type="event4", bus_target=bus, t_start=t, amount=amount)


def _event5(rng: random.Random, t: float) -> ScenarioEvent:
    return ScenarioEvent(
        type="event5",
        pmu_target=rng.choice(OBSERVED_PMUS),
        t_start=t,
        duration=round(rng.uniform(0.2, 2.0), 3),
        severity=round(rng.uniform(0.3, 1.0), 3),
    )


def _event7(rng: random.Random, t: float) -> ScenarioEvent:
    signals = ("VA_MAG", "VB_MAG", "VC_MAG", "IA_MAG", "IB_MAG", "IC_MAG", "VA_ANG", "IA_ANG", "Freq")
    return ScenarioEvent(
        type="event7",
        pmu_target=rng.choice(OBSERVED_PMUS),
        signal_target=rng.choice(signals),
        t_start=t,
        duration=round(rng.uniform(0.1, 1.5), 3),
        severity=round(rng.uniform(2.0, 8.0), 3),
    )


def _event8(rng: random.Random, t: float) -> ScenarioEvent:
    return ScenarioEvent(
        type="event8",
        bus_target=rng.randint(1, 39),
        pmu_target=rng.choice(OBSERVED_PMUS),
        signal_target=rng.choice(("VA_MAG", "IA_MAG", "VA_ANG", "Freq")),
        t_start=t,
        duration=round(rng.uniform(0.3, 2.5), 3),
        severity=round(rng.uniform(0.5, 3.0), 3),
    )


def _sequence_for(events: list[ScenarioEvent]) -> tuple[str, ...]:
    seq = ["event0"]
    for event in sorted(events, key=lambda item: item.t_start):
        seq.extend([event.type, "event0"])
    return tuple(seq)


def _scenario(sim_no: int, seed: int, events: list[ScenarioEvent], note: str) -> Scenario:
    rng = random.Random(seed + sim_no * 17)
    labels = {
        "has_anomaly": bool(events),
        "event_types": sorted({event.type for event in events}),
        "physical_targets": [
            {
                "type": event.type,
                "bus": event.bus_target,
                "line": event.line_target,
                "line_from": event.line_from,
                "line_to": event.line_to,
            }
            for event in events
            if event.type in {"event1", "event2", "event3", "event4"}
        ],
        "cyber_targets": [
            {"type": event.type, "pmu": event.pmu_target, "signal": event.signal_target}
            for event in events
            if event.type in {"event5", "event7"}
        ],
    }
    return Scenario(
        sim_id=f"SIM{sim_no:05d}",
        schema_version="sgsma-scenario-v1",
        random_seed=seed,
        duration_s=30.0,
        dt_s=1.0 / 30.0,
        observed_pmus=OBSERVED_PMUS,
        sequence=_sequence_for(events),
        events=tuple(events),
        labels=labels,
        raw_profile={
            "enabled": True,
            "event0_chunk": rng.choice(
                (
                    "chunk1_event0",
                    "chunk3_event0",
                    "chunk5_event0",
                    "chunk7_event0",
                    "chunk9_event0",
                    "chunk11_event0",
                    "chunk13_event0",
                    "chunk15_event0",
                    "chunk17_event0",
                    "chunk21_event0",
                    "chunk23_event0",
                )
            ),
            "start_fraction": round(rng.uniform(0.0, 0.60), 4),
        },
        notes=note,
    )


def _random_physical_event(
    rng: random.Random,
    event_type: str,
    line_targets: list[dict[str, Any]],
    gen_buses: tuple[int, ...],
    load_buses: tuple[int, ...],
    t: float,
) -> ScenarioEvent:
    if event_type == "event1":
        return _event1(rng.randint(1, 39), t, rng)
    if event_type == "event2":
        return _event2(rng.choice(line_targets), t)
    if event_type == "event3":
        return _event3(rng.choice(gen_buses), t, rng)
    if event_type == "event4":
        return _event4(rng.choice(load_buses), t, rng)
    raise ValueError(event_type)


def _line_by_endpoints(line_targets: list[dict[str, Any]], a: int, b: int) -> dict[str, Any] | None:
    key = {int(a), int(b)}
    for line in line_targets:
        if {int(line["line_from"]), int(line["line_to"])} == key:
            return line
    return None


def _add_raw_localizer_focus(
    scenarios: list[Scenario],
    seed: int,
    rng: random.Random,
    line_targets: list[dict[str, Any]],
    count: int,
) -> None:
    if count <= 0:
        return
    focus_events: list[tuple[str, Any]] = []
    for bus in RAW_LOCALIZER_FOCUS_BUSES:
        focus_events.extend([("event1", bus), ("event3", bus), ("event4", bus)])
    for a, b in RAW_LOCALIZER_FOCUS_LINES:
        line = _line_by_endpoints(line_targets, a, b)
        if line is not None:
            focus_events.append(("event2", line))
    idx = 0
    while idx < int(count):
        kind, target = focus_events[idx % len(focus_events)]
        t = round(rng.uniform(4.0, 12.0), 3)
        if kind == "event1":
            event = _event1(int(target), t, rng)
        elif kind == "event2":
            event = _event2(target, t)
        elif kind == "event3":
            event = _event3(int(target), t, rng)
        elif kind == "event4":
            event = _event4(int(target), t, rng)
        else:
            raise ValueError(kind)
        scenarios.append(
            _scenario(
                len(scenarios) + 1,
                seed + len(scenarios),
                [event],
                f"focus:raw_localizer_{kind}",
            )
        )
        idx += 1


def build_scenario_set(n: int, seed: int, raw_path: Path, raw_localizer_focus: int = 0) -> tuple[list[Scenario], dict[str, Any]]:
    rng = random.Random(seed)
    line_targets = _line_targets(raw_path)
    gen_buses = _generator_buses_from_case() or GENERATOR_BUSES
    load_buses = _load_buses_from_case("PQ") or FALLBACK_LOAD_BUSES
    scenarios: list[Scenario] = []

    normal_count = max(80, int(round(n * 0.12)))
    for _ in range(normal_count):
        scenarios.append(_scenario(len(scenarios) + 1, seed + len(scenarios), [], "coverage:event0_normal_raw_profile"))

    for bus in range(1, 40):
        scenarios.append(_scenario(len(scenarios) + 1, seed, [_event1(bus, 5.0, rng)], "coverage:event1_all_buses"))
    for line in line_targets:
        scenarios.append(_scenario(len(scenarios) + 1, seed, [_event2(line, 5.0)], "coverage:event2_first_34_lines"))
    for bus in gen_buses:
        scenarios.append(_scenario(len(scenarios) + 1, seed, [_event3(bus, 5.0, rng)], "coverage:event3_generator_buses"))
    for bus in load_buses:
        scenarios.append(_scenario(len(scenarios) + 1, seed, [_event4(bus, 5.0, rng)], "coverage:event4_load_buses"))
    _add_raw_localizer_focus(scenarios, seed, rng, line_targets, raw_localizer_focus)

    event_weights = [
        ("event0", 0.10),
        ("event1", 0.20),
        ("event2", 0.17),
        ("event3", 0.13),
        ("event4", 0.13),
        ("event6", 0.11),
        ("event5", 0.06),
        ("event7", 0.06),
        ("event8", 0.04),
    ]
    event_names = [name for name, _ in event_weights]
    weights = [weight for _, weight in event_weights]
    while len(scenarios) < n:
        kind = rng.choices(event_names, weights=weights, k=1)[0]
        t = round(rng.uniform(4.0, 12.0), 3)
        events: list[ScenarioEvent]
        note = "random"
        if kind == "event0":
            events = []
            note = "random:event0_normal_raw_profile"
        elif kind == "event6":
            e1 = _random_physical_event(
                rng,
                rng.choice(("event1", "event2", "event3", "event4")),
                line_targets,
                gen_buses,
                load_buses,
                t,
            )
            cyber = _event5(rng, round(t + rng.uniform(-0.1, 0.1), 3))
            events = [e1, cyber]
            note = "proxy:event6_concurrent_physical_missing_data"
        elif kind == "event5":
            events = [_event5(rng, t)]
        elif kind == "event7":
            events = [_event7(rng, t)]
        elif kind == "event8":
            events = [_event8(rng, t)]
        else:
            events = [_random_physical_event(rng, kind, line_targets, gen_buses, load_buses, t)]
            if kind == "event1" and rng.random() < 0.18:
                events.append(_event1(rng.randint(1, 39), round(t + rng.uniform(3.0, 9.0), 3), rng))
                note = "random:multi_fault"
        scenarios.append(_scenario(len(scenarios) + 1, seed + len(scenarios), events, note))

    manifest = {
        "schema_version": "sgsma-scenario-manifest-v1",
        "n_scenarios": len(scenarios),
        "seed": seed,
        "observed_pmus": list(OBSERVED_PMUS),
        "event2_line_targets": line_targets,
        "event3_generator_buses": list(gen_buses),
        "event4_load_buses": list(load_buses),
        "raw_localizer_focus_count": int(raw_localizer_focus),
        "raw_localizer_focus_buses": list(RAW_LOCALIZER_FOCUS_BUSES),
        "raw_localizer_focus_lines": [list(item) for item in RAW_LOCALIZER_FOCUS_LINES],
        "counts_by_primary_event": {},
    }
    for scenario in scenarios:
        key = scenario.events[0].type if scenario.events else "event0"
        if scenario.notes.startswith("proxy:event6"):
            key = "event6"
        manifest["counts_by_primary_event"][key] = manifest["counts_by_primary_event"].get(key, 0) + 1
    return scenarios, manifest


def write_scenarios(scenarios: list[Scenario], manifest: dict[str, Any], out_dir: Path) -> None:
    out_dir.mkdir(parents=True, exist_ok=True)
    for scenario in scenarios:
        path = out_dir / f"{scenario.sim_id}.json"
        path.write_text(json.dumps(_json_safe(asdict(scenario)), indent=2), encoding="utf-8")
    (out_dir / "scenario_manifest.json").write_text(json.dumps(_json_safe(manifest), indent=2), encoding="utf-8")


def generate_scenarios(
    n: int = 1000,
    seed: int = 20260502,
    out_dir: Path = DEFAULT_OUT,
    raw_localizer_focus: int = 0,
) -> dict[str, Any]:
    scenarios, manifest = build_scenario_set(n=n, seed=seed, raw_path=DEFAULT_RAW, raw_localizer_focus=raw_localizer_focus)
    write_scenarios(scenarios, manifest, out_dir)
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Generate SGSMA synthetic simulation scenario JSON files.")
    parser.add_argument("--n", type=int, default=1000)
    parser.add_argument("--seed", type=int, default=20260502)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--raw-localizer-focus", type=int, default=0)
    args = parser.parse_args()
    manifest = generate_scenarios(n=args.n, seed=args.seed, out_dir=args.out_dir, raw_localizer_focus=args.raw_localizer_focus)
    print(json.dumps(_json_safe(manifest), indent=2))


if __name__ == "__main__":
    main()
