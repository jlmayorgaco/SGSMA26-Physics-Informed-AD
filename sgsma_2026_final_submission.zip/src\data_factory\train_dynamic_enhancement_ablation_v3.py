from __future__ import annotations

import argparse
import json
from concurrent.futures import ProcessPoolExecutor, as_completed
from itertools import combinations
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.ensemble import ExtraTreesClassifier
from sklearn.impute import SimpleImputer
from sklearn.metrics import accuracy_score, confusion_matrix, f1_score, recall_score
from sklearn.model_selection import train_test_split
from sklearn.pipeline import Pipeline

from src.data_factory.dynamic_feature_extractor_v3 import extract_dynamic_features_from_frames, load_pmu_frames
from src.data_factory.evaluate_raw0001_v2 import (
    DEFAULT_RAW_DIR,
    DEFAULT_TIMELINE,
    _load_raw_frames,
    _official_label,
    _official_location,
    _window_bounds,
)
from src.data_factory.train_hierarchical_pipeline import (
    DEFAULT_SIM_DIR,
    _event_label,
    _json_safe,
    _location_label,
    _location_type,
    _metrics,
    _physical_event_label,
)


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_TOPOLOGY_DIST = ROOT / "data" / "topology" / "ieee39" / "zbus_effective_distance_full.csv"
DEFAULT_OUT = ROOT / "models" / "sgsma_2026_factory_v3_dynamic_ablation"
BLOCKS = ("rolling", "rls_kalman", "hilbert", "graph_temporal", "residual_topology")
BLOCK_PREFIX = {
    "rolling": "ROLL__",
    "rls_kalman": "RLSK__",
    "hilbert": "HILB__",
    "graph_temporal": "GRAPH__",
    "residual_topology": "RESID__",
}
COMMON_PREFIXES = ("META__",)
EVENT_LABELS = list(range(9))
EVENT_PRIORITY_LABELS: set[int] = set()


def _tree(random_state: int, n_estimators: int = 260) -> Pipeline:
    return Pipeline(
        steps=[
            ("imputer", SimpleImputer(strategy="median")),
            (
                "model",
                ExtraTreesClassifier(
                    n_estimators=int(n_estimators),
                    min_samples_leaf=1,
                    max_features="sqrt",
                    class_weight="balanced",
                    n_jobs=-1,
                    random_state=int(random_state),
                ),
            ),
        ]
    )


def _variant_name(blocks: tuple[str, ...]) -> str:
    return "+".join(blocks)


def _all_variants() -> list[tuple[str, ...]]:
    variants: list[tuple[str, ...]] = []
    for size in range(1, len(BLOCKS) + 1):
        variants.extend(tuple(item) for item in combinations(BLOCKS, size))
    return variants


def _feature_columns_for_variant(data: pd.DataFrame, blocks: tuple[str, ...]) -> list[str]:
    prefixes = COMMON_PREFIXES + tuple(BLOCK_PREFIX[block] for block in blocks)
    ignored = {"sim_id", "chunk_name", "event_label", "abnormal_label", "physical_event_label", "location_label", "location_type"}
    out = []
    for col in data.columns:
        if col in ignored:
            continue
        if not col.startswith(prefixes):
            continue
        if pd.api.types.is_numeric_dtype(data[col]):
            out.append(col)
    return out


def _build_sim_row(manifest_path: Path, topology_csv: Path) -> dict[str, Any]:
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    scenario = json.loads(Path(manifest["scenario_json"]).read_text(encoding="utf-8"))
    events = list(scenario.get("events", []))
    location = _location_label(events)
    frames = load_pmu_frames(Path(manifest["pmu_dir"]))
    topology = pd.read_csv(topology_csv)
    row: dict[str, Any] = {
        "sim_id": str(manifest["sim_id"]),
        "event_label": _event_label(events),
        "abnormal_label": int(bool(events)),
        "physical_event_label": _physical_event_label(events),
        "location_label": location,
        "location_type": _location_type(location),
    }
    row.update(extract_dynamic_features_from_frames(frames, topology, include_blocks=BLOCKS))
    return row


def build_dynamic_sim_dataset(
    sim_dir: Path,
    topology_csv: Path,
    out_csv: Path,
    force: bool = False,
    workers: int = 1,
    max_samples: int | None = None,
) -> pd.DataFrame:
    if out_csv.exists() and not force:
        data = pd.read_csv(out_csv)
        if max_samples is not None and len(data) > int(max_samples):
            return data.iloc[: int(max_samples)].reset_index(drop=True)
        return data
    manifest_paths = sorted(sim_dir.glob("SIM*/manifest.json"))
    if max_samples is not None:
        manifest_paths = manifest_paths[: int(max_samples)]
    rows: list[dict[str, Any]] = []
    if int(workers) <= 1:
        for idx, manifest_path in enumerate(manifest_paths, start=1):
            rows.append(_build_sim_row(manifest_path, topology_csv))
            if idx == 1 or idx == len(manifest_paths) or idx % 250 == 0:
                print(f"dynamic features {idx}/{len(manifest_paths)}", flush=True)
    else:
        with ProcessPoolExecutor(max_workers=int(workers)) as pool:
            futures = [pool.submit(_build_sim_row, path, topology_csv) for path in manifest_paths]
            for idx, future in enumerate(as_completed(futures), start=1):
                rows.append(future.result())
                if idx == 1 or idx == len(manifest_paths) or idx % 250 == 0:
                    print(f"dynamic features {idx}/{len(manifest_paths)}", flush=True)
    data = pd.DataFrame(rows).sort_values("sim_id").reset_index(drop=True)
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    data.to_csv(out_csv, index=False)
    return data


def _segment_raw_frames(frames: dict[int, pd.DataFrame], window_start: float, window_end: float) -> dict[int, pd.DataFrame]:
    out = {}
    for bus, frame in sorted(frames.items()):
        mask = (frame["TIMESTAMP"] >= window_start) & (frame["TIMESTAMP"] <= window_end)
        segment = frame.loc[mask].copy()
        if segment.empty:
            continue
        segment["TIMESTAMP"] = segment["TIMESTAMP"] - window_start
        out[int(bus)] = segment
    return out


def build_dynamic_raw_dataset(
    raw_dir: Path,
    timeline_csv: Path,
    topology_csv: Path,
    out_csv: Path,
    force: bool = False,
    context_seconds: float = 30.0,
) -> tuple[pd.DataFrame, list[str]]:
    if out_csv.exists() and not force:
        return pd.read_csv(out_csv), []
    frames = _load_raw_frames(raw_dir)
    topology = pd.read_csv(topology_csv)
    timeline = pd.read_csv(timeline_csv)
    global_start = min(float(frame["TIMESTAMP"].min()) for frame in frames.values())
    global_end = max(float(frame["TIMESTAMP"].max()) for frame in frames.values())
    rows: list[dict[str, Any]] = []
    skipped: list[str] = []
    for _, event_row in timeline.iterrows():
        bounds = _window_bounds(event_row, global_start, global_end, context_seconds)
        if bounds is None:
            skipped.append(str(event_row["chunk_name"]))
            continue
        window_start, window_end = bounds
        true_event = _official_label(event_row)
        true_location = _official_location(event_row)
        row: dict[str, Any] = {
            "chunk_name": str(event_row["chunk_name"]),
            "event_label": int(true_event),
            "abnormal_label": int(true_event != 0),
            "physical_event_label": int(true_event) if int(true_event) in {1, 2, 3, 4, 8} else 0,
            "location_label": true_location,
            "location_type": _location_type(true_location),
            "window_start": float(window_start),
            "window_end": float(window_end),
        }
        segments = _segment_raw_frames(frames, window_start, window_end)
        row.update(extract_dynamic_features_from_frames(segments, topology, include_blocks=BLOCKS))
        rows.append(row)
    data = pd.DataFrame(rows)
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    data.to_csv(out_csv, index=False)
    return data, skipped


def _fit_localizers(x_train: pd.DataFrame, data_train: pd.DataFrame, random_state: int, n_estimators: int) -> dict[str, Pipeline]:
    models: dict[str, Pipeline] = {}
    stable_seed = {"BUS": 101, "LINE": 202, "PMU": 303}
    for event_label in sorted(data_train["event_label"].unique().tolist()):
        event_label = int(event_label)
        if event_label == 0:
            continue
        mask = data_train["event_label"].eq(event_label) & data_train["location_label"].ne("none")
        if mask.sum() < 2 or data_train.loc[mask, "location_label"].nunique() < 2:
            continue
        key = f"EVENT:event{event_label}"
        model = _tree(random_state + 3000 + event_label, n_estimators=n_estimators)
        model.fit(x_train.loc[mask], data_train.loc[mask, "location_label"])
        models[key] = model
    for loc_type in ("BUS", "LINE", "PMU"):
        mask = data_train["location_type"].eq(loc_type)
        if mask.sum() < 2 or data_train.loc[mask, "location_label"].nunique() < 2:
            continue
        model = _tree(random_state + stable_seed[loc_type], n_estimators=n_estimators)
        model.fit(x_train.loc[mask], data_train.loc[mask, "location_label"])
        models[loc_type] = model
    for physical_label in sorted(data_train["physical_event_label"].unique().tolist()):
        physical_label = int(physical_label)
        if physical_label == 0:
            continue
        loc_type = "LINE" if physical_label == 2 else "BUS"
        mask = data_train["location_type"].eq(loc_type) & data_train["physical_event_label"].eq(physical_label)
        if mask.sum() < 2 or data_train.loc[mask, "location_label"].nunique() < 2:
            continue
        key = f"{loc_type}:event{physical_label}"
        model = _tree(random_state + 2000 + physical_label, n_estimators=n_estimators)
        model.fit(x_train.loc[mask], data_train.loc[mask, "location_label"])
        models[key] = model
    return models


def _predict_locations(x: pd.DataFrame, pred_event: np.ndarray, physical_pred: np.ndarray, models: dict[str, Pipeline]) -> np.ndarray:
    out = np.full(len(x), "none", dtype=object)
    unresolved = np.ones(len(x), dtype=bool)
    for event_label in sorted(set(int(value) for value in pred_event)):
        if event_label == 0 or event_label not in EVENT_PRIORITY_LABELS:
            continue
        model = models.get(f"EVENT:event{event_label}")
        if model is None:
            continue
        mask = unresolved & (pred_event == event_label)
        if mask.any():
            out[mask] = model.predict(x.loc[mask])
            unresolved[mask] = False
    loc_type = np.full(len(x), "BUS", dtype=object)
    loc_type[np.isin(physical_pred, [2]) | np.isin(pred_event, [2])] = "LINE"
    loc_type[np.isin(pred_event, [5, 7])] = "PMU"
    loc_type[pred_event == 0] = "NONE"
    line_event2 = models.get("LINE:event2")
    if line_event2 is not None:
        mask = unresolved & (pred_event == 2)
        if mask.any():
            out[mask] = line_event2.predict(x.loc[mask])
            unresolved[mask] = False
    for physical_label in sorted(set(int(value) for value in physical_pred)):
        if physical_label == 0:
            continue
        current_type = "LINE" if physical_label == 2 else "BUS"
        key = f"{current_type}:event{physical_label}"
        model = models.get(key)
        if model is None:
            continue
        mask = unresolved & (loc_type == current_type) & (physical_pred == physical_label)
        if mask.any():
            out[mask] = model.predict(x.loc[mask])
            unresolved[mask] = False
    for current_type in ("BUS", "LINE", "PMU"):
        model = models.get(current_type)
        if model is None:
            continue
        mask = unresolved & (loc_type == current_type) & pd.Series(out).eq("none").to_numpy()
        if mask.any():
            out[mask] = model.predict(x.loc[mask])
            unresolved[mask] = False
    return out


def _location_report(data: pd.DataFrame, pred_location: np.ndarray) -> dict[str, Any]:
    mask = data["location_label"].ne("none")
    if not mask.any():
        return {"evaluated": 0, "exact_accuracy": 0.0, "type_confusion_matrix": []}
    true = data.loc[mask, "location_label"].reset_index(drop=True)
    pred = pd.Series(pred_location[mask], dtype=object).reset_index(drop=True)
    true_type = true.map(_location_type)
    pred_type = pred.map(_location_type)
    by_event: dict[str, Any] = {}
    events = data.loc[mask, "event_label"].reset_index(drop=True)
    for event in sorted(events.unique().tolist()):
        event_mask = events.eq(event)
        by_event[str(int(event))] = {
            "support": int(event_mask.sum()),
            "accuracy": float((true[event_mask].to_numpy() == pred[event_mask].to_numpy()).mean()) if event_mask.any() else 0.0,
        }
    return {
        "evaluated": int(mask.sum()),
        "exact_accuracy": float((true.to_numpy() == pred.to_numpy()).mean()),
        "macro_f1": float(f1_score(true, pred, average="macro", zero_division=0)),
        "type_labels": ["BUS", "LINE", "PMU"],
        "type_confusion_matrix": confusion_matrix(true_type, pred_type, labels=["BUS", "LINE", "PMU"]).tolist(),
        "by_event": by_event,
    }


def _evaluate_models(
    data: pd.DataFrame,
    feature_cols: list[str],
    event_model: Pipeline,
    physical_model: Pipeline,
    localizers: dict[str, Pipeline],
) -> dict[str, Any]:
    x = data.reindex(columns=feature_cols, fill_value=np.nan)
    pred_event = event_model.predict(x).astype(int)
    pred_physical = physical_model.predict(x).astype(int)
    pred_abnormal = (pred_event != 0).astype(int)
    pred_location = _predict_locations(x, pred_event, pred_physical, localizers)
    out = {
        "detector": {
            **_metrics(data["abnormal_label"], pred_abnormal, labels=[0, 1]),
            "abnormal_recall": float(recall_score(data["abnormal_label"], pred_abnormal, pos_label=1, zero_division=0)),
        },
        "classifier": _metrics(data["event_label"], pred_event, labels=EVENT_LABELS),
        "physical_classifier": _metrics(
            data["physical_event_label"],
            pred_physical,
            labels=sorted(data["physical_event_label"].unique().tolist()),
        ),
        "localizer": _location_report(data, pred_location),
    }
    return out


def _train_variant(
    data: pd.DataFrame,
    train_idx: np.ndarray,
    test_idx: np.ndarray,
    blocks: tuple[str, ...],
    random_state: int,
    n_estimators: int,
) -> tuple[dict[str, Any], dict[str, Any]]:
    feature_cols = _feature_columns_for_variant(data, blocks)
    x = data[feature_cols]
    x_train = x.iloc[train_idx].reset_index(drop=True)
    data_train = data.iloc[train_idx].reset_index(drop=True)
    data_test = data.iloc[test_idx].reset_index(drop=True)

    event_model = _tree(random_state + 1, n_estimators=n_estimators)
    event_model.fit(x_train, data_train["event_label"])
    physical_model = _tree(random_state + 2, n_estimators=n_estimators)
    physical_model.fit(x_train, data_train["physical_event_label"])
    localizers = _fit_localizers(x_train, data_train, random_state + 10, n_estimators=n_estimators)
    sim_report = _evaluate_models(data_test, feature_cols, event_model, physical_model, localizers)
    models = {
        "event_model": event_model,
        "physical_model": physical_model,
        "localizers": localizers,
        "feature_cols": feature_cols,
    }
    return sim_report, models


def run_ablation(
    sim_dir: Path = DEFAULT_SIM_DIR,
    raw_dir: Path = DEFAULT_RAW_DIR,
    timeline_csv: Path = DEFAULT_TIMELINE,
    topology_csv: Path = DEFAULT_TOPOLOGY_DIST,
    out_dir: Path = DEFAULT_OUT,
    random_state: int = 20260503,
    force_features: bool = False,
    workers: int = 1,
    max_samples: int | None = None,
    n_estimators: int = 260,
    skip_raw: bool = False,
) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    sample_tag = f"_{int(max_samples)}" if max_samples is not None else ""
    feature_csv = out_dir / f"dynamic_features_v3{sample_tag}.csv"
    data = build_dynamic_sim_dataset(sim_dir, topology_csv, feature_csv, force=force_features, workers=workers, max_samples=max_samples)
    raw_data = None
    raw_skipped: list[str] = []
    if not skip_raw:
        raw_csv = out_dir / "raw0001_dynamic_features_v3.csv"
        raw_data, raw_skipped = build_dynamic_raw_dataset(raw_dir, timeline_csv, topology_csv, raw_csv, force=force_features)

    train_idx, test_idx = train_test_split(
        np.arange(len(data)),
        test_size=0.30,
        random_state=random_state,
        stratify=data["event_label"],
    )

    summary_rows: list[dict[str, Any]] = []
    reports: dict[str, Any] = {}
    best_key: tuple[float, float, float] | None = None
    best_payload: dict[str, Any] | None = None
    variants = _all_variants()
    for idx, blocks in enumerate(variants, start=1):
        name = _variant_name(blocks)
        print(f"training variant {idx}/{len(variants)}: {name}", flush=True)
        sim_report, models = _train_variant(data, train_idx, test_idx, blocks, random_state + idx * 100, n_estimators)
        raw_report = None
        if raw_data is not None:
            raw_report = _evaluate_models(
                raw_data,
                models["feature_cols"],
                models["event_model"],
                models["physical_model"],
                models["localizers"],
            )
        row = {
            "variant": name,
            "blocks": ",".join(blocks),
            "n_features": int(len(models["feature_cols"])),
            "sim_detector_accuracy": float(sim_report["detector"]["accuracy"]),
            "sim_classifier_accuracy": float(sim_report["classifier"]["accuracy"]),
            "sim_classifier_macro_f1": float(sim_report["classifier"]["macro_f1"]),
            "sim_localizer_exact": float(sim_report["localizer"]["exact_accuracy"]),
            "raw_detector_accuracy": float(raw_report["detector"]["accuracy"]) if raw_report else np.nan,
            "raw_classifier_accuracy": float(raw_report["classifier"]["accuracy"]) if raw_report else np.nan,
            "raw_classifier_macro_f1": float(raw_report["classifier"]["macro_f1"]) if raw_report else np.nan,
            "raw_localizer_exact": float(raw_report["localizer"]["exact_accuracy"]) if raw_report else np.nan,
        }
        summary_rows.append(row)
        reports[name] = {"blocks": blocks, "summary": row, "sim": sim_report, "raw": raw_report}
        key = (row["sim_localizer_exact"], row["sim_classifier_macro_f1"], -float(len(models["feature_cols"])))
        if best_key is None or key > best_key:
            best_key = key
            best_payload = {
                "variant": name,
                "blocks": blocks,
                "models": models,
                "summary": row,
            }

    summary = pd.DataFrame(summary_rows).sort_values(
        ["sim_localizer_exact", "sim_classifier_macro_f1", "raw_localizer_exact"],
        ascending=[False, False, False],
    )
    summary_path = out_dir / f"dynamic_ablation_v3_summary{sample_tag}.csv"
    summary.to_csv(summary_path, index=False)
    report = {
        "dataset": {
            "sim_dir": str(sim_dir.resolve()),
            "dynamic_features_csv": str(feature_csv.resolve()),
            "n_samples": int(len(data)),
            "train_samples": int(len(train_idx)),
            "test_samples": int(len(test_idx)),
            "event_counts": {str(k): int(v) for k, v in data["event_label"].value_counts().sort_index().items()},
            "rolling_windows": [5, 15, 30, 60, 120],
            "blocks": list(BLOCKS),
            "raw_windows": int(len(raw_data)) if raw_data is not None else 0,
            "raw_skipped": raw_skipped,
        },
        "best_variant": best_payload["summary"] if best_payload else None,
        "variants": reports,
    }
    report_path = out_dir / f"dynamic_ablation_v3_report{sample_tag}.json"
    report_path.write_text(json.dumps(_json_safe(report), indent=2), encoding="utf-8")
    if best_payload is not None:
        joblib.dump(
            {
                "variant": best_payload["variant"],
                "blocks": best_payload["blocks"],
                **best_payload["models"],
            },
            out_dir / f"dynamic_ablation_v3_best_models{sample_tag}.joblib",
        )
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description="Train dynamic enhancement ablations for SGSMA v3.")
    parser.add_argument("--sim-dir", type=Path, default=DEFAULT_SIM_DIR)
    parser.add_argument("--raw-dir", type=Path, default=DEFAULT_RAW_DIR)
    parser.add_argument("--timeline-csv", type=Path, default=DEFAULT_TIMELINE)
    parser.add_argument("--topology-csv", type=Path, default=DEFAULT_TOPOLOGY_DIST)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--random-state", type=int, default=20260503)
    parser.add_argument("--force-features", action="store_true")
    parser.add_argument("--workers", type=int, default=1)
    parser.add_argument("--max-samples", type=int)
    parser.add_argument("--n-estimators", type=int, default=260)
    parser.add_argument("--skip-raw", action="store_true")
    args = parser.parse_args()
    report = run_ablation(
        sim_dir=args.sim_dir,
        raw_dir=args.raw_dir,
        timeline_csv=args.timeline_csv,
        topology_csv=args.topology_csv,
        out_dir=args.out_dir,
        random_state=args.random_state,
        force_features=bool(args.force_features),
        workers=max(1, int(args.workers)),
        max_samples=args.max_samples,
        n_estimators=int(args.n_estimators),
        skip_raw=bool(args.skip_raw),
    )
    compact = {
        "dataset": report["dataset"],
        "best_variant": report["best_variant"],
    }
    print(json.dumps(_json_safe(compact), indent=2))


if __name__ == "__main__":
    main()
