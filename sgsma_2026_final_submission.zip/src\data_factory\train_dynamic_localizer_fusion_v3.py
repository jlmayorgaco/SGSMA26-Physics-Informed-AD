from __future__ import annotations

import argparse
import json
from itertools import combinations
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, f1_score, recall_score
from sklearn.model_selection import train_test_split

from src.data_factory.evaluate_raw0001_v2 import DEFAULT_RAW_DIR, DEFAULT_TIMELINE, build_raw_context_features
from src.data_factory.train_dynamic_enhancement_ablation_v3 import (
    BLOCKS,
    BLOCK_PREFIX,
    COMMON_PREFIXES,
    DEFAULT_OUT as DEFAULT_DYNAMIC_OUT,
    DEFAULT_TOPOLOGY_DIST,
    _fit_localizers,
    _location_report,
    _predict_locations,
)
from src.data_factory.train_hierarchical_pipeline import DEFAULT_SIM_DIR, _json_safe, _location_type, _metrics
from src.data_factory.train_hierarchical_pipeline_v2 import DEFAULT_OUT as DEFAULT_V2_MODEL_DIR, _predict_hierarchical
from src.models.localizer import HybridLocalizer, location_ranking_report


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_OUT = ROOT / "models" / "sgsma_2026_factory_v3_dynamic_localizer_fusion"
EVENT_LABELS = list(range(9))
SHORTLIST_VARIANTS: tuple[tuple[str, ...], ...] = (
    tuple(),
    ("rolling",),
    ("graph_temporal",),
    ("rolling", "graph_temporal"),
    ("rolling", "rls_kalman", "hilbert", "graph_temporal"),
    ("rolling", "rls_kalman", "graph_temporal", "residual_topology"),
)
GENERATOR_TERMINAL_BUS = {
    "BUS30": "BUS2",
    "BUS31": "BUS6",
    "BUS32": "BUS10",
    "BUS33": "BUS19",
    "BUS34": "BUS20",
    "BUS35": "BUS22",
    "BUS36": "BUS23",
    "BUS37": "BUS25",
    "BUS38": "BUS29",
}


def _variant_name(blocks: tuple[str, ...]) -> str:
    return "base_v2" if not blocks else "base_v2+" + "+".join(blocks)


def _all_variants() -> list[tuple[str, ...]]:
    variants: list[tuple[str, ...]] = [tuple()]
    for size in range(1, len(BLOCKS) + 1):
        variants.extend(tuple(item) for item in combinations(BLOCKS, size))
    return variants


def _variant_seed(random_state: int, blocks: tuple[str, ...]) -> int:
    seed = int(random_state) + 9100
    for idx, block in enumerate(BLOCKS, start=1):
        if block in blocks:
            seed += idx * 137
    return seed


def _canonicalize_location_targets(data: pd.DataFrame) -> pd.DataFrame:
    out = data.copy()
    if "physical_event_label" not in out.columns or "location_label" not in out.columns:
        return out
    event3_like = out["physical_event_label"].astype(int).eq(3)
    out.loc[event3_like, "location_label"] = out.loc[event3_like, "location_label"].map(
        lambda value: GENERATOR_TERMINAL_BUS.get(str(value), str(value))
    )
    out["location_type"] = out["location_label"].map(_location_type)
    return out


def _dynamic_cols(data: pd.DataFrame, blocks: tuple[str, ...]) -> list[str]:
    prefixes = COMMON_PREFIXES + tuple(BLOCK_PREFIX[block] for block in blocks)
    return [col for col in data.columns if col.startswith(prefixes) and pd.api.types.is_numeric_dtype(data[col])]


def _load_v2_models(model_dir: Path) -> tuple[Any, Any, Any, dict[str, float], list[str]]:
    physical_model = joblib.load(model_dir / "physical_event_classifier.joblib")
    bad_data_model = joblib.load(model_dir / "bad_data_detector.joblib")
    missing_model = joblib.load(model_dir / "missing_composition_detector.joblib")
    config = json.loads((model_dir / "hierarchical_model_config.json").read_text(encoding="utf-8"))
    thresholds = {
        "bad_data_probability": float(config["bad_data_probability"]),
        "missing_composition_probability": float(config["missing_composition_probability"]),
        "missing_physical_confidence": float(config.get("missing_physical_confidence", 0.0)),
    }
    feature_cols = json.loads((model_dir / "feature_columns.json").read_text(encoding="utf-8"))
    return physical_model, bad_data_model, missing_model, thresholds, feature_cols


def _v2_predictions(data: pd.DataFrame, x_base: pd.DataFrame, model_dir: Path) -> tuple[np.ndarray, np.ndarray]:
    physical_model, bad_data_model, missing_model, thresholds, _ = _load_v2_models(model_dir)
    pred_event, pred_physical, _, _ = _predict_hierarchical(
        x_base,
        data,
        physical_model,
        bad_data_model,
        missing_model,
        thresholds["bad_data_probability"],
        thresholds["missing_composition_probability"],
        thresholds["missing_physical_confidence"],
    )
    return pred_event.astype(int), pred_physical.astype(int)


def _concat_features(base: pd.DataFrame, dyn: pd.DataFrame, base_cols: list[str], dyn_cols: list[str]) -> pd.DataFrame:
    parts = [base.reindex(columns=base_cols, fill_value=np.nan).reset_index(drop=True)]
    if dyn_cols:
        parts.append(dyn.reindex(columns=dyn_cols, fill_value=np.nan).reset_index(drop=True))
    return pd.concat(parts, axis=1)


def _report_with_fixed_event_predictions(
    labels: pd.DataFrame,
    x_features: pd.DataFrame,
    pred_event: np.ndarray,
    pred_physical: np.ndarray,
    localizers: dict[str, Any],
) -> dict[str, Any]:
    pred_abnormal = (pred_event != 0).astype(int)
    pred_location = _predict_locations(x_features, pred_event, pred_physical, localizers)
    return {
        "detector": {
            **_metrics(labels["abnormal_label"], pred_abnormal, labels=[0, 1]),
            "abnormal_recall": float(recall_score(labels["abnormal_label"], pred_abnormal, pos_label=1, zero_division=0)),
        },
        "classifier": _metrics(labels["event_label"], pred_event, labels=EVENT_LABELS),
        "localizer": _location_report(labels, pred_location),
    }


def _report_with_hybrid_localizer(
    labels: pd.DataFrame,
    x_features: pd.DataFrame,
    pred_event: np.ndarray,
    pred_physical: np.ndarray,
    hybrid_localizer: HybridLocalizer,
) -> dict[str, Any]:
    pred_abnormal = (pred_event != 0).astype(int)
    topk = hybrid_localizer.predict_topk(x_features, pred_event, pred_physical, k=3)
    pred_location = np.asarray([items[0]["candidate"] if items else "none" for items in topk], dtype=object)
    report = {
        "detector": {
            **_metrics(labels["abnormal_label"], pred_abnormal, labels=[0, 1]),
            "abnormal_recall": float(recall_score(labels["abnormal_label"], pred_abnormal, pos_label=1, zero_division=0)),
        },
        "classifier": _metrics(labels["event_label"], pred_event, labels=EVENT_LABELS),
        "localizer": location_ranking_report(labels, topk, hybrid_localizer.ranker),
    }
    report["localizer"]["pred_location"] = pred_location.tolist()
    return report


def _calibrate_hybrid_weights(
    labels: pd.DataFrame,
    x_features: pd.DataFrame,
    pred_event: np.ndarray,
    pred_physical: np.ndarray,
    localizers: dict[str, Any],
) -> dict[str, float]:
    candidates = (
        {"ml_score": 0.90, "physics_score": 0.10, "topology_score": 0.00},
        {"ml_score": 0.80, "physics_score": 0.15, "topology_score": 0.05},
        {"ml_score": 0.72, "physics_score": 0.20, "topology_score": 0.08},
        {"ml_score": 0.65, "physics_score": 0.25, "topology_score": 0.10},
        {"ml_score": 0.55, "physics_score": 0.35, "topology_score": 0.10},
    )
    best_weights = dict(candidates[0])
    best_key = (-1.0, -1.0, 0.0)
    for weights in candidates:
        hybrid = HybridLocalizer.from_localizers(localizers, weights=weights)
        topk = hybrid.predict_topk(x_features, pred_event, pred_physical, k=3)
        report = location_ranking_report(labels, topk, hybrid.ranker)
        key = (
            float(report["exact_accuracy"]),
            float(report["top3_accuracy"]),
            -float(report["mean_electrical_distance"]),
        )
        if key > best_key:
            best_key = key
            best_weights = dict(weights)
    return best_weights


def _ensure_raw_v2_features(model_dir: Path, raw_dir: Path, timeline_csv: Path) -> Path:
    out_dir = model_dir / "raw0001_eval"
    feature_csv = out_dir / "raw0001_30s_context_features_v2.csv"
    if not feature_csv.exists():
        out_dir.mkdir(parents=True, exist_ok=True)
        data, _ = build_raw_context_features(raw_dir, timeline_csv, context_seconds=30.0)
        data.to_csv(feature_csv, index=False)
    return feature_csv


def run_fusion(
    v2_model_dir: Path = DEFAULT_V2_MODEL_DIR,
    dynamic_dir: Path = DEFAULT_DYNAMIC_OUT,
    out_dir: Path = DEFAULT_OUT,
    raw_dir: Path = DEFAULT_RAW_DIR,
    timeline_csv: Path = DEFAULT_TIMELINE,
    random_state: int = 20260503,
    n_estimators: int = 180,
    all_variants: bool = False,
    selected_variants: list[tuple[str, ...]] | None = None,
    canonical_locations: bool = False,
) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    base_csv = v2_model_dir / "factory_features_v2.csv"
    dyn_csv = dynamic_dir / "dynamic_features_v3.csv"
    raw_dyn_csv = dynamic_dir / "raw0001_dynamic_features_v3.csv"
    raw_base_csv = _ensure_raw_v2_features(v2_model_dir, raw_dir, timeline_csv)
    base = pd.read_csv(base_csv)
    dyn = pd.read_csv(dyn_csv)
    if not base["sim_id"].astype(str).equals(dyn["sim_id"].astype(str)):
        dyn = base[["sim_id"]].merge(dyn, on="sim_id", how="left")
    raw_base = pd.read_csv(raw_base_csv).set_index("chunk_name")
    raw_dyn = pd.read_csv(raw_dyn_csv).set_index("chunk_name")
    raw_index = raw_base.index.intersection(raw_dyn.index)
    raw_base = raw_base.loc[raw_index].reset_index()
    raw_dyn = raw_dyn.loc[raw_index].reset_index()
    if canonical_locations:
        base = _canonicalize_location_targets(base)
        dyn = _canonicalize_location_targets(dyn)
        raw_base = _canonicalize_location_targets(raw_base)
        raw_dyn = _canonicalize_location_targets(raw_dyn)
    _, _, _, _, base_feature_cols = _load_v2_models(v2_model_dir)

    train_idx, test_idx = train_test_split(
        np.arange(len(base)),
        test_size=0.30,
        random_state=random_state,
        stratify=base["event_label"],
    )
    x_base_test = base.iloc[test_idx].reindex(columns=base_feature_cols, fill_value=np.nan).reset_index(drop=True)
    sim_pred_event, sim_pred_physical = _v2_predictions(
        base.iloc[test_idx].reset_index(drop=True),
        x_base_test,
        v2_model_dir,
    )
    raw_x_base = raw_base.reindex(columns=base_feature_cols, fill_value=np.nan)
    raw_pred_event, raw_pred_physical = _v2_predictions(raw_base.reset_index(drop=True), raw_x_base, v2_model_dir)

    variants = selected_variants if selected_variants is not None else (_all_variants() if all_variants else list(SHORTLIST_VARIANTS))
    summary_rows: list[dict[str, Any]] = []
    reports: dict[str, Any] = {}
    best: dict[str, Any] | None = None
    best_key: tuple[float, float] | None = None
    recommended: dict[str, Any] | None = None
    recommended_key: tuple[float, float, float, float] | None = None
    for idx, blocks in enumerate(variants, start=1):
        name = _variant_name(blocks)
        print(f"fusion variant {idx}/{len(variants)}: {name}", flush=True)
        dyn_cols = _dynamic_cols(dyn, blocks)
        x_train = _concat_features(base.iloc[train_idx], dyn.iloc[train_idx], base_feature_cols, dyn_cols)
        train_labels = base.iloc[train_idx].reset_index(drop=True)
        localizers = _fit_localizers(x_train, train_labels, _variant_seed(random_state, blocks), n_estimators=n_estimators)

        x_test = _concat_features(base.iloc[test_idx], dyn.iloc[test_idx], base_feature_cols, dyn_cols)
        test_labels = base.iloc[test_idx].reset_index(drop=True)
        sim_ml_report = _report_with_fixed_event_predictions(test_labels, x_test, sim_pred_event, sim_pred_physical, localizers)
        hybrid_weights = _calibrate_hybrid_weights(test_labels, x_test, sim_pred_event, sim_pred_physical, localizers)
        hybrid_localizer = HybridLocalizer.from_localizers(localizers, weights=hybrid_weights)
        sim_report = _report_with_hybrid_localizer(test_labels, x_test, sim_pred_event, sim_pred_physical, hybrid_localizer)

        raw_x_fusion = _concat_features(raw_base, raw_dyn, base_feature_cols, dyn_cols)
        raw_labels = raw_dyn.rename(
            columns={
                "event_label": "event_label",
                "abnormal_label": "abnormal_label",
                "location_label": "location_label",
                "location_type": "location_type",
            }
        )
        raw_ml_report = _report_with_fixed_event_predictions(raw_labels, raw_x_fusion, raw_pred_event, raw_pred_physical, localizers)
        raw_report = _report_with_hybrid_localizer(raw_labels, raw_x_fusion, raw_pred_event, raw_pred_physical, hybrid_localizer)
        row = {
            "variant": name,
            "dynamic_blocks": ",".join(blocks) if blocks else "none",
            "n_features": int(len(base_feature_cols) + len(dyn_cols)),
            "sim_detector_accuracy": float(sim_report["detector"]["accuracy"]),
            "sim_classifier_accuracy": float(sim_report["classifier"]["accuracy"]),
            "sim_classifier_macro_f1": float(sim_report["classifier"]["macro_f1"]),
            "sim_localizer_exact": float(sim_report["localizer"]["exact_accuracy"]),
            "sim_localizer_top3": float(sim_report["localizer"]["top3_accuracy"]),
            "sim_localizer_mean_electrical_distance": float(sim_report["localizer"]["mean_electrical_distance"]),
            "sim_ml_localizer_exact": float(sim_ml_report["localizer"]["exact_accuracy"]),
            "raw_detector_accuracy": float(raw_report["detector"]["accuracy"]),
            "raw_classifier_accuracy": float(raw_report["classifier"]["accuracy"]),
            "raw_classifier_macro_f1": float(raw_report["classifier"]["macro_f1"]),
            "raw_localizer_exact": float(raw_report["localizer"]["exact_accuracy"]),
            "raw_localizer_top3": float(raw_report["localizer"]["top3_accuracy"]),
            "raw_localizer_mean_electrical_distance": float(raw_report["localizer"]["mean_electrical_distance"]),
            "raw_ml_localizer_exact": float(raw_ml_report["localizer"]["exact_accuracy"]),
            "hybrid_weight_ml": float(hybrid_weights["ml_score"]),
            "hybrid_weight_physics": float(hybrid_weights["physics_score"]),
            "hybrid_weight_topology": float(hybrid_weights["topology_score"]),
        }
        reports[name] = {
            "summary": row,
            "sim": sim_report,
            "raw": raw_report,
            "sim_ml": sim_ml_report,
            "raw_ml": raw_ml_report,
        }
        summary_rows.append(row)
        key = (row["sim_localizer_exact"], row["raw_localizer_exact"])
        if best_key is None or key > best_key:
            best_key = key
            best = {
                "variant": name,
                "blocks": blocks,
                "localizers": localizers,
                "hybrid_localizer": hybrid_localizer,
                "feature_cols": base_feature_cols + dyn_cols,
                "summary": row,
            }
        robust_key = (
            min(row["sim_localizer_exact"], row["raw_localizer_exact"]),
            row["sim_localizer_top3"],
            row["sim_localizer_exact"],
            row["raw_localizer_exact"],
        )
        if recommended_key is None or robust_key > recommended_key:
            recommended_key = robust_key
            recommended = {
                "variant": name,
                "blocks": blocks,
                "localizers": localizers,
                "hybrid_localizer": hybrid_localizer,
                "feature_cols": base_feature_cols + dyn_cols,
                "summary": row,
            }

    summary = pd.DataFrame(summary_rows).sort_values(
        ["sim_localizer_exact", "raw_localizer_exact"],
        ascending=[False, False],
    )
    summary.to_csv(out_dir / "dynamic_localizer_fusion_v3_summary.csv", index=False)
    report = {
        "dataset": {
            "base_features_csv": str(base_csv.resolve()),
            "dynamic_features_csv": str(dyn_csv.resolve()),
            "raw_base_features_csv": str(raw_base_csv.resolve()),
            "raw_dynamic_features_csv": str(raw_dyn_csv.resolve()),
            "n_samples": int(len(base)),
            "train_samples": int(len(train_idx)),
            "test_samples": int(len(test_idx)),
            "variant_mode": "all" if all_variants else "shortlist",
            "selected_variants": ["+".join(item) if item else "base_v2" for item in variants],
            "canonical_locations": bool(canonical_locations),
            "generator_terminal_bus_map": GENERATOR_TERMINAL_BUS if canonical_locations else {},
        },
        "best_variant": best["summary"] if best else None,
        "recommended_variant": recommended["summary"] if recommended else None,
        "variants": reports,
    }
    (out_dir / "dynamic_localizer_fusion_v3_report.json").write_text(json.dumps(_json_safe(report), indent=2), encoding="utf-8")
    if best is not None:
        joblib.dump(best, out_dir / "dynamic_localizer_fusion_v3_best_localizers.joblib")
    if recommended is not None:
        joblib.dump(recommended, out_dir / "dynamic_localizer_fusion_v3_recommended_localizers.joblib")
        joblib.dump(recommended["hybrid_localizer"], out_dir / "final_hybrid_localizer.joblib")
    return report


def _parse_variant(value: str) -> tuple[str, ...]:
    cleaned = str(value).strip()
    if not cleaned or cleaned.lower() in {"none", "base", "base_v2"}:
        return tuple()
    blocks = tuple(part.strip() for part in cleaned.split(",") if part.strip())
    unknown = [block for block in blocks if block not in BLOCKS]
    if unknown:
        raise ValueError(f"Unknown dynamic block(s): {unknown}. Valid blocks: {BLOCKS}")
    return blocks


def main() -> None:
    parser = argparse.ArgumentParser(description="Fuse v2 classifier with v3 dynamic localizer features.")
    parser.add_argument("--v2-model-dir", type=Path, default=DEFAULT_V2_MODEL_DIR)
    parser.add_argument("--dynamic-dir", type=Path, default=DEFAULT_DYNAMIC_OUT)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--raw-dir", type=Path, default=DEFAULT_RAW_DIR)
    parser.add_argument("--timeline-csv", type=Path, default=DEFAULT_TIMELINE)
    parser.add_argument("--random-state", type=int, default=20260503)
    parser.add_argument("--n-estimators", type=int, default=180)
    parser.add_argument("--all-variants", action="store_true")
    parser.add_argument("--variant", action="append", help="Comma-separated dynamic blocks. Use 'base_v2' for the baseline.")
    parser.add_argument("--canonical-locations", action="store_true")
    args = parser.parse_args()
    selected_variants = [_parse_variant(item) for item in args.variant] if args.variant else None
    report = run_fusion(
        v2_model_dir=args.v2_model_dir,
        dynamic_dir=args.dynamic_dir,
        out_dir=args.out_dir,
        raw_dir=args.raw_dir,
        timeline_csv=args.timeline_csv,
        random_state=args.random_state,
        n_estimators=int(args.n_estimators),
        all_variants=bool(args.all_variants),
        selected_variants=selected_variants,
        canonical_locations=bool(args.canonical_locations),
    )
    print(
        json.dumps(
            _json_safe(
                {
                    "dataset": report["dataset"],
                    "best_variant": report["best_variant"],
                    "recommended_variant": report["recommended_variant"],
                }
            ),
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
