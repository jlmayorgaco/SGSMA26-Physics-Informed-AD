"""Model wrappers used by the final SGSMA inference bundle."""

