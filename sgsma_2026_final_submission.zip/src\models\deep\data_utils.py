from __future__ import annotations

import re
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch

from src.helpers.paths import ROOT

OBSERVED_PMUS = (2, 5, 6, 10, 19, 22, 29, 39)
PMU_NAMES = [f"BUS{bus}" for bus in OBSERVED_PMUS]

DEFAULT_TOPOLOGY_DIR = ROOT / "data" / "topology" / "ieee39"
DEFAULT_RAW_DIR = ROOT / "workbench" / "raw_current_eval"


def load_topology(topology_dir: Path = DEFAULT_TOPOLOGY_DIR) -> dict[str, Any]:
    """Load topology data: Zbus distances and branch list."""
    dist_path = topology_dir / "zbus_effective_distance_full.csv"
    branches_path = topology_dir / "branches_physical.csv"
    dist_matrix = np.ones((39, 39))
    lines: list[tuple[int, int]] = []
    if dist_path.exists():
        dist_df = pd.read_csv(dist_path)
        for _, row in dist_df.iterrows():
            i, j = int(row["from_bus"]) - 1, int(row["to_bus"]) - 1
            dist_matrix[i, j] = max(float(row["z_eff_abs"]), 1e-6)
            dist_matrix[j, i] = dist_matrix[i, j]
    if branches_path.exists():
        branches = pd.read_csv(branches_path)
        for _, row in branches.iterrows():
            a, b = int(row["from_bus"]), int(row["to_bus"])
            if a <= 39 and b <= 39:
                lines.append((min(a, b), max(a, b)))
    return {"distance_matrix": dist_matrix, "lines": sorted(set(lines)), "observed_pmus": list(OBSERVED_PMUS)}


def _get_pmu_features(data: pd.DataFrame, pmu_name: str) -> pd.Series | None:
    prefix = f"{pmu_name}__"
    cols = [col for col in data.columns if col.startswith(prefix)]
    if not cols:
        return None
    return data[cols].iloc[0] if len(data) > 0 else pd.Series(dtype=float)


def _extract_pmu_node_features(data: pd.DataFrame, pmu_names: list[str] = PMU_NAMES) -> np.ndarray:
    """Extract per-PMU node feature vectors from the feature DataFrame."""
    node_feats = []
    for pmu in pmu_names:
        cols = [col for col in data.columns if col.startswith(f"{pmu}__") and pd.api.types.is_numeric_dtype(data[col])]
        if cols:
            node_feats.append(data[cols].values)
        else:
            node_feats.append(np.zeros((len(data), 1)))
    min_cols = min(f.shape[1] for f in node_feats)
    aligned = [f[:, :min_cols].copy() for f in node_feats]
    return np.stack(aligned, axis=1)


def prepare_raw001_data(
    base_csv: Path | None = None,
    dyn_csv: Path | None = None,
) -> dict[str, Any]:
    """Load and prepare RAW001 evaluation data."""
    raw_dir = DEFAULT_RAW_DIR
    base_csv = Path(base_csv) if base_csv else raw_dir / "raw001_base_features_v2.csv"
    dyn_csv = Path(dyn_csv) if dyn_csv else raw_dir / "raw001_dynamic_features_v3.csv"

    base = pd.read_csv(base_csv)
    dyn = pd.read_csv(dyn_csv)

    if "window_start" in base.columns and "window_start" in dyn.columns:
        dyn = dyn.rename(columns={
            "window_start": "ws",
            "window_end": "we",
            "event_label": "event_label_dyn",
            "abnormal_label": "abnormal_label_dyn",
            "location_label": "location_label_dyn",
            "location_type": "location_type_dyn",
        })

    labels = pd.DataFrame({
        "true_event": base["true_event"].values,
        "true_abnormal": base["true_abnormal"].values,
        "event_signature": base["event_signature"].values if "event_signature" in base.columns else ["unknown"] * len(base),
        "true_location": base["true_location"].values if "true_location" in base.columns else (base.get("target_location", pd.Series(["unknown"] * len(base))).values),
    })
    labels["true_abnormal"] = labels["true_abnormal"].astype(int)
    labels["true_event"] = labels["true_event"].astype(int)

    node_feats_base = _extract_pmu_node_features(base)
    pmu_node_features = node_feats_base.astype(np.float32)

    return {
        "base_features": base,
        "dynamic_features": dyn,
        "labels": labels,
        "pmu_node_features": pmu_node_features,
        "n_samples": len(base),
        "node_feat_dim": pmu_node_features.shape[2],
    }


def generate_synthetic_training_data(
    raw_data: dict[str, Any] | None = None,
    n_samples: int = 2000,
    noise_scale: float = 0.05,
    random_seed: int = 42,
) -> dict[str, Any]:
    """Generate synthetic training data by bootstrapping from RAW001 features with topological augmentation."""
    rng = np.random.RandomState(random_seed)

    if raw_data is not None and raw_data.get("pmu_node_features") is not None:
        raw_features = raw_data["pmu_node_features"]
        raw_labels_df = raw_data["labels"]
        n_raw, n_pmu, n_feat = raw_features.shape
    else:
        n_pmu, n_feat = 8, 1417
        raw_features = np.random.randn(10, n_pmu, n_feat).astype(np.float32) * 0.5
        raw_labels_df = pd.DataFrame({
            "true_event": np.random.choice([0, 1, 2, 3, 4, 5, 7], 10),
            "true_abnormal": np.random.choice([0, 1], 10),
            "true_location": ["BUS1"] * 10,
        })
        n_raw = 10

    synthetic_features = []
    synthetic_det_labels = []
    synthetic_cls_labels = []
    synthetic_loc_labels = []

    for _ in range(n_samples):
        idx = rng.randint(0, n_raw)
        base_feat = raw_features[idx].copy()

        noise = rng.randn(n_pmu, n_feat).astype(np.float32) * noise_scale
        base_feat = base_feat + noise

        true_event = int(raw_labels_df.iloc[idx]["true_event"])
        true_abnormal = int(raw_labels_df.iloc[idx]["true_abnormal"])

        if rng.random() < 0.3 and n_raw > 1:
            idx2 = rng.randint(0, n_raw)
            alpha = rng.uniform(0.3, 0.7)
            base_feat = alpha * base_feat + (1 - alpha) * raw_features[idx2]

        pmu_perm = rng.choice(n_pmu, size=rng.randint(1, 3), replace=False)
        for p in pmu_perm:
            base_feat[p] *= rng.uniform(0.9, 1.1)

        synthetic_features.append(base_feat)
        synthetic_det_labels.append(true_abnormal)
        synthetic_cls_labels.append(true_event)

        loc = str(raw_labels_df.iloc[idx]["true_location"])
        synthetic_loc_labels.append(loc)

    features_array = np.stack(synthetic_features, axis=0)
    return {
        "features": features_array,
        "det_labels": np.array(synthetic_det_labels, dtype=np.int64),
        "cls_labels": np.array(synthetic_cls_labels, dtype=np.int64),
        "loc_labels": np.array(synthetic_loc_labels),
        "n_samples": n_samples,
        "n_pmu": n_pmu,
        "n_features": n_feat,
    }


def features_to_graph_batch(
    node_features: np.ndarray,
    edge_index: torch.Tensor,
    edge_attr: torch.Tensor | None = None,
) -> dict[str, torch.Tensor]:
    """Convert per-sample node features to batched graph input."""
    n_samples, n_nodes, n_feat = node_features.shape
    x_batched = torch.tensor(node_features.reshape(-1, n_feat), dtype=torch.float)

    edge_list = []
    for i in range(n_samples):
        edge_list.append(edge_index + i * n_nodes)
    full_edge_index = torch.cat(edge_list, dim=1)

    return {"x": x_batched, "edge_index": full_edge_index, "edge_attr": edge_attr}
