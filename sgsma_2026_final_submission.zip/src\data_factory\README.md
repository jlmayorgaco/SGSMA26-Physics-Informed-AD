# Data Factory

This package contains the code behind the submitted `models/` bundle.

## Active Path

The production path is intentionally small:

1. Build the IEEE 39 topology files.
2. Generate RAW-profiled synthetic cases.
3. Extract base V2 window features.
4. Train the detector and event classifier.
5. Add rolling, RLS/Kalman-like, and graph-temporal features.
6. Train the typed BUS/LINE/PMU localizer.
7. Evaluate against RAW001 windows.

The ordered wrappers in `pipelines/` are the supported way to run these steps.

## Core Modules

| Module | Purpose |
| --- | --- |
| `topology_extractor.py` | Builds Ybus, Zbus, electrical-distance matrices, and branch metadata. |
| `raw_timeline.py` | Rebuilds the RAW001 event-window timeline. |
| `scenario_generator.py` | Writes reproducible scenario JSON files. |
| `andes_batch_runner.py` | Generates PMU and hidden-bus CSVs with the RAWANDES-PMU surrogate. |
| `feature_extractor_v2.py` | Extracts base physical, cyber, statistical, and topology features. |
| `dynamic_feature_extractor_v3.py` | Adds temporal and graph-aware feature blocks. |
| `train_hierarchical_pipeline_v2.py` | Trains the detector/classifier backbone. |
| `train_dynamic_localizer_fusion_v3.py` | Trains the selected dynamic localizer. |
| `final_model.py` | Loads `models/detector`, `models/classifiers`, and `models/localizer` for inference from extracted features. |

## Not In The Submission Path

Several variants were tested and intentionally kept out of the active code path: algebraic residual localization, swing/EKF-lite residuals, topology oracle ranking, earlier graph-state models, and LightGBM-only trials. They are documented in `overview.md` and the report because they explain the model choice, but they are not needed to run the submitted workflow.
