from __future__ import annotations

import argparse
import json
import re
from pathlib import Path
from typing import Any

import pandas as pd


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_RAW_DIR = ROOT / "data" / "RAW0001"
DEFAULT_METADATA_XLSX = ROOT / "data" / "metadata" / "Event Timeline & Location.xlsx"
DEFAULT_OUT = ROOT / "data" / "event_profiles" / "raw0001_event_timeline.csv"


RAW001_CANONICAL_WINDOWS: tuple[dict[str, Any], ...] = (
    {
        "chunk_name": "chunk2_event7",
        "event_code": 7,
        "start_time": 540.0,
        "duration_seconds": 20.0,
        "event_signature": "event7(bad_data)",
        "target_location": "Bus2",
        "active_buses": "Bus2",
    },
    {
        "chunk_name": "chunk3_event0",
        "event_code": 0,
        "start_time": 570.0,
        "duration_seconds": 30.0,
        "event_signature": "event0",
        "target_location": "",
        "active_buses": "",
    },
    {
        "chunk_name": "chunk4_event7",
        "event_code": 7,
        "start_time": 600.0,
        "duration_seconds": 20.0,
        "event_signature": "event7(bad_data)",
        "target_location": "Bus39",
        "active_buses": "Bus39",
    },
    {
        "chunk_name": "chunk6_event7",
        "event_code": 7,
        "start_time": 660.0,
        "duration_seconds": 20.0,
        "event_signature": "event7(bad_data)",
        "target_location": "Bus39",
        "active_buses": "Bus39",
    },
    {
        "chunk_name": "chunk7_event0",
        "event_code": 0,
        "start_time": 720.0,
        "duration_seconds": 30.0,
        "event_signature": "event0",
        "target_location": "",
        "active_buses": "",
    },
    {
        "chunk_name": "chunk8_event5",
        "event_code": 5,
        "start_time": 780.0,
        "duration_seconds": 20.0,
        "event_signature": "event5(missing_data)",
        "target_location": "Bus29",
        "active_buses": "Bus29",
    },
    {
        "chunk_name": "chunk9_event0",
        "event_code": 0,
        "start_time": 900.0,
        "duration_seconds": 30.0,
        "event_signature": "event0",
        "target_location": "",
        "active_buses": "",
    },
    {
        "chunk_name": "chunk10_event5",
        "event_code": 5,
        "start_time": 1020.0,
        "duration_seconds": 20.0,
        "event_signature": "event5(missing_data)",
        "target_location": "Bus29",
        "active_buses": "Bus29",
    },
    {
        "chunk_name": "chunk11_event0",
        "event_code": 0,
        "start_time": 1140.0,
        "duration_seconds": 30.0,
        "event_signature": "event0",
        "target_location": "",
        "active_buses": "",
    },
    {
        "chunk_name": "chunk12_event1",
        "event_code": 1,
        "start_time": 1200.0,
        "duration_seconds": 0.15,
        "event_signature": "event1(3lg_fault)",
        "target_location": "Bus39",
        "active_buses": "Bus39",
    },
    {
        "chunk_name": "chunk13_event0",
        "event_code": 0,
        "start_time": 1230.0,
        "duration_seconds": 30.0,
        "event_signature": "event0",
        "target_location": "",
        "active_buses": "",
    },
    {
        "chunk_name": "chunk14_event2",
        "event_code": 2,
        "start_time": 2400.0,
        "duration_seconds": 1.0,
        "event_signature": "event2(line_outage)",
        "target_location": "Line23-24",
        "active_buses": "Bus23|Bus24",
    },
    {
        "chunk_name": "chunk15_event0",
        "event_code": 0,
        "start_time": 2430.0,
        "duration_seconds": 30.0,
        "event_signature": "event0",
        "target_location": "",
        "active_buses": "",
    },
    {
        "chunk_name": "chunk16_event5",
        "event_code": 5,
        "start_time": 2700.0,
        "duration_seconds": 20.0,
        "event_signature": "event5(missing_data)",
        "target_location": "Bus29",
        "active_buses": "Bus29",
    },
    {
        "chunk_name": "chunk17_event0",
        "event_code": 0,
        "start_time": 2730.0,
        "duration_seconds": 30.0,
        "event_signature": "event0",
        "target_location": "",
        "active_buses": "",
    },
    {
        "chunk_name": "chunk18_event5",
        "event_code": 5,
        "start_time": 2940.0,
        "duration_seconds": 20.0,
        "event_signature": "event5(missing_data)",
        "target_location": "Bus29",
        "active_buses": "Bus29",
    },
    {
        "chunk_name": "chunk19_event3",
        "event_code": 3,
        "start_time": 3000.0,
        "duration_seconds": 20.0,
        "event_signature": "event3+6(concurrent_generation_missing_data)",
        "target_location": "Bus2",
        "active_buses": "Bus29|Bus2",
    },
    {
        "chunk_name": "chunk20_event3",
        "event_code": 3,
        "start_time": 3300.0,
        "duration_seconds": 20.0,
        "event_signature": "event3(generation_change)",
        "target_location": "Bus2",
        "active_buses": "Bus2",
    },
    {
        "chunk_name": "chunk21_event0",
        "event_code": 0,
        "start_time": 3330.0,
        "duration_seconds": 30.0,
        "event_signature": "event0",
        "target_location": "",
        "active_buses": "",
    },
    {
        "chunk_name": "chunk22_event4",
        "event_code": 4,
        "start_time": 5100.0,
        "duration_seconds": 20.0,
        "event_signature": "event4(load_change)",
        "target_location": "Bus7",
        "active_buses": "Bus7",
    },
    {
        "chunk_name": "chunk23_event0",
        "event_code": 0,
        "start_time": 5130.0,
        "duration_seconds": 30.0,
        "event_signature": "event0",
        "target_location": "",
        "active_buses": "",
    },
)


def _raw_time_bounds(raw_dir: Path) -> tuple[float, float]:
    csv_paths = sorted(raw_dir.glob("Bus*_Competition_Data_nanmask.csv"))
    if not csv_paths:
        raise FileNotFoundError(f"No RAW001 PMU CSV files found in {raw_dir}")
    starts: list[float] = []
    ends: list[float] = []
    for path in csv_paths:
        timestamps = pd.read_csv(path, usecols=["TIMESTAMP"])["TIMESTAMP"]
        starts.append(float(timestamps.min()))
        ends.append(float(timestamps.max()))
    return min(starts), max(ends)


def _metadata_minutes(metadata_xlsx: Path) -> dict[str, float]:
    if not metadata_xlsx.exists():
        return {}
    try:
        frame = pd.read_excel(metadata_xlsx)
    except Exception:
        return {}
    out: dict[str, float] = {}
    for _, row in frame.dropna(how="all").iterrows():
        location = str(row.get("Event Location", "")).strip().replace(" ", "")
        impact = str(row.get("Event Impcat", "")).strip().lower()
        approx = str(row.get("Approximated Time", ""))
        match = re.search(r"(\d+(?:\.\d+)?)", approx)
        if not match:
            continue
        minute = float(match.group(1))
        key = f"{impact}:{location}".lower()
        out[key] = minute * 60.0
    return out


def build_raw0001_timeline(
    raw_dir: Path = DEFAULT_RAW_DIR,
    metadata_xlsx: Path = DEFAULT_METADATA_XLSX,
    out_csv: Path = DEFAULT_OUT,
    force: bool = False,
) -> pd.DataFrame:
    if out_csv.exists() and not force:
        return pd.read_csv(out_csv)

    global_start, global_end = _raw_time_bounds(raw_dir)
    metadata_anchors = _metadata_minutes(metadata_xlsx)
    rows = []
    for item in RAW001_CANONICAL_WINDOWS:
        row = dict(item)
        if row["chunk_name"] == "chunk12_event1":
            row["start_time"] = metadata_anchors.get("triple line to ground fault at bus 39:bus39", row["start_time"])
        elif row["chunk_name"] == "chunk14_event2":
            row["start_time"] = metadata_anchors.get("line outage between bus 24 and bus23:bus24", row["start_time"])
        elif row["chunk_name"] in {"chunk19_event3", "chunk20_event3"}:
            row["start_time"] = metadata_anchors.get("generation change at bus 2:bus2", row["start_time"])
            if row["chunk_name"] == "chunk20_event3":
                row["start_time"] += 300.0
        elif row["chunk_name"] == "chunk22_event4":
            row["start_time"] = min(row["start_time"], global_end - 60.0)
        row["start_time"] = max(global_start, min(float(row["start_time"]), global_end - 5.0))
        row["end_time"] = min(global_end, float(row["start_time"]) + float(row["duration_seconds"]))
        rows.append(row)
    data = pd.DataFrame(rows)
    out_csv.parent.mkdir(parents=True, exist_ok=True)
    data.to_csv(out_csv, index=False)
    return data


def main() -> None:
    parser = argparse.ArgumentParser(description="Build the canonical RAW001 event-window timeline CSV.")
    parser.add_argument("--raw-dir", type=Path, default=DEFAULT_RAW_DIR)
    parser.add_argument("--metadata-xlsx", type=Path, default=DEFAULT_METADATA_XLSX)
    parser.add_argument("--out-csv", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--force", action="store_true")
    args = parser.parse_args()
    data = build_raw0001_timeline(
        raw_dir=args.raw_dir,
        metadata_xlsx=args.metadata_xlsx,
        out_csv=args.out_csv,
        force=bool(args.force),
    )
    print(json.dumps({"out_csv": str(args.out_csv.resolve()), "rows": int(len(data))}, indent=2))


if __name__ == "__main__":
    main()
