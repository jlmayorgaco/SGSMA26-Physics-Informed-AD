from __future__ import annotations

import math
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd
import torch
import torch.nn as nn
import torch.nn.functional as F
from torch_geometric.nn import GATConv, global_mean_pool
from torch_geometric.data import Data

from src.helpers.paths import ROOT

OBSERVED_PMUS = (2, 5, 6, 10, 19, 22, 29, 39)
N_BUSES = 39
PMU_SIGNALS = 14
WINDOW_SAMPLES = 90

DEFAULT_TOPOLOGY_DIR = ROOT / "data" / "topology" / "ieee39"


class PositionalEncoding(nn.Module):
    def __init__(self, d_model: int, max_len: int = 200):
        super().__init__()
        pe = torch.zeros(max_len, d_model)
        position = torch.arange(0, max_len, dtype=torch.float).unsqueeze(1)
        div_term = torch.exp(torch.arange(0, d_model, 2).float() * (-math.log(10000.0) / d_model))
        pe[:, 0::2] = torch.sin(position * div_term)
        pe[:, 1::2] = torch.cos(position * div_term)
        self.register_buffer("pe", pe)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return x + self.pe[: x.size(1)]


class TCNBlock(nn.Module):
    def __init__(self, in_channels: int, out_channels: int, kernel_size: int = 3, dilation: int = 1, dropout: float = 0.1):
        super().__init__()
        padding = (kernel_size - 1) * dilation
        self.conv1 = nn.Conv1d(in_channels, out_channels, kernel_size, padding=padding, dilation=dilation)
        self.conv2 = nn.Conv1d(out_channels, out_channels, kernel_size, padding=padding, dilation=dilation)
        self.dropout = nn.Dropout(dropout)
        self.downsample = nn.Conv1d(in_channels, out_channels, 1) if in_channels != out_channels else nn.Identity()
        self.activation = nn.ReLU()

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        residual = self.downsample(x)
        out = self.activation(self.conv1(x))
        out = self.dropout(out)
        out = self.conv2(out)
        out = self.activation(out + residual)
        return self.dropout(out)


class TemporalCNN(nn.Module):
    """Temporal CNN for per-PMU time-series encoding."""

    def __init__(self, in_channels: int = 14, hidden_channels: int = 64, out_channels: int = 128, num_layers: int = 4, dropout: float = 0.1):
        super().__init__()
        self.pos_encoder = PositionalEncoding(in_channels)
        layers = []
        ch_in = in_channels
        for i in range(num_layers):
            ch_out = hidden_channels * (2 ** min(i, 1))
            layers.append(TCNBlock(ch_in, ch_out, kernel_size=3, dilation=2**i, dropout=dropout))
            ch_in = ch_out
        self.tcn = nn.Sequential(*layers)
        self.pool = nn.AdaptiveAvgPool1d(1)
        self.proj = nn.Linear(ch_in, out_channels)

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        if x.dim() == 2:
            x = x.unsqueeze(0)
        x = self.pos_encoder(x.transpose(1, 2))
        x = x.transpose(1, 2)
        x = self.tcn(x)
        x = self.pool(x).squeeze(-1)
        return self.proj(x)


class GraphAttentionEncoder(nn.Module):
    """Graph Attention Network for spatial PMU fusion over 39-bus topology."""

    def __init__(self, in_channels: int, hidden_channels: int = 128, out_channels: int = 256, num_layers: int = 2, heads: int = 4, dropout: float = 0.1):
        super().__init__()
        self.num_layers = num_layers
        self.heads = heads
        self.dropout = dropout

        self.input_proj = nn.Linear(in_channels, hidden_channels)

        self.gat_layers = nn.ModuleList()
        for i in range(num_layers):
            is_last = i == num_layers - 1
            layer_heads = 1 if is_last else heads
            concat = not is_last
            in_dim = hidden_channels if i == 0 else hidden_channels * heads
            out_dim = hidden_channels if not is_last else out_channels
            self.gat_layers.append(GATConv(in_dim, out_dim, heads=layer_heads, concat=concat, dropout=dropout))

        self.readout = nn.Sequential(
            nn.Linear(out_channels, out_channels),
            nn.ReLU(),
            nn.Dropout(dropout),
        )

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor, edge_attr: torch.Tensor | None = None) -> torch.Tensor:
        x = self.input_proj(x)
        x = F.relu(x)
        for i, gat in enumerate(self.gat_layers):
            x = gat(x, edge_index)
            if i < self.num_layers - 1:
                x = F.relu(x)
                x = F.dropout(x, p=self.dropout, training=self.training)
        x = self.readout(x)
        return x


class DetectionHead(nn.Module):
    """Binary detector head: normal (0) vs abnormal (1)."""

    def __init__(self, in_channels: int, hidden: int = 128, dropout: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_channels, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden // 2),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden // 2, 1),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x).squeeze(-1)


class ClassificationHead(nn.Module):
    """9-class event classifier: labels 0-8."""

    def __init__(self, in_channels: int, num_classes: int = 9, hidden: int = 128, dropout: float = 0.1):
        super().__init__()
        self.net = nn.Sequential(
            nn.Linear(in_channels, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, num_classes),
        )

    def forward(self, x: torch.Tensor) -> torch.Tensor:
        return self.net(x)


class LocalizationHead(nn.Module):
    """Multi-type localizer head with per-location-type routing."""

    def __init__(self, in_channels: int, num_bus: int = 39, num_line: int = 34, num_pmu: int = 8, hidden: int = 128, dropout: float = 0.1):
        super().__init__()
        self.bus_head = nn.Sequential(
            nn.Linear(in_channels, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, num_bus),
        )
        self.line_head = nn.Sequential(
            nn.Linear(in_channels, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, num_line),
        )
        self.pmu_head = nn.Sequential(
            nn.Linear(in_channels, hidden),
            nn.ReLU(),
            nn.Dropout(dropout),
            nn.Linear(hidden, num_pmu),
        )

    def forward(self, x: torch.Tensor, loc_type: str = "BUS") -> torch.Tensor:
        if loc_type == "BUS":
            return self.bus_head(x)
        elif loc_type == "LINE":
            return self.line_head(x)
        else:
            return self.pmu_head(x)


class SGSMADeepModel(nn.Module):
    """Complete SGSMA deep model: detector + classifier + localizer with shared GNN encoder.

    Uses graph-level batching: node features for N graphs are concatenated,
    edge_index is offset per graph, and `batch` tensor maps each node to its graph.
    """

    def __init__(
        self,
        node_feat_dim: int = 1417,
        num_classes: int = 9,
        num_bus: int = 39,
        num_line: int = 34,
        num_pmu: int = 8,
        hidden: int = 128,
        num_gat_layers: int = 2,
        heads: int = 4,
        dropout: float = 0.1,
    ):
        super().__init__()
        self.node_feat_dim = node_feat_dim
        self.hidden = hidden
        self.encoder = GraphAttentionEncoder(node_feat_dim, hidden_channels=hidden, out_channels=hidden * 2, num_layers=num_gat_layers, heads=heads, dropout=dropout)
        self.detector_head = DetectionHead(hidden * 2, hidden=hidden, dropout=dropout)
        self.classifier_head = ClassificationHead(hidden * 2, num_classes=num_classes, hidden=hidden, dropout=dropout)
        self.localizer_head = LocalizationHead(hidden * 2, num_bus=num_bus, num_line=num_line, num_pmu=num_pmu, hidden=hidden, dropout=dropout)

    def forward(self, x: torch.Tensor, edge_index: torch.Tensor, batch: torch.Tensor, edge_attr: torch.Tensor | None = None):
        node_emb = self.encoder(x, edge_index, edge_attr)
        graph_emb = global_mean_pool(node_emb, batch)
        det_logits = self.detector_head(graph_emb)
        cls_logits = self.classifier_head(graph_emb)
        bus_logits = self.localizer_head.bus_head(graph_emb)
        return det_logits, cls_logits, bus_logits, node_emb, graph_emb

    def predict(self, x: torch.Tensor, edge_index: torch.Tensor, batch: torch.Tensor, edge_attr: torch.Tensor | None = None) -> dict[str, np.ndarray]:
        self.eval()
        with torch.no_grad():
            det_logits, cls_logits, bus_logits, _, _ = self.forward(x, edge_index, batch, edge_attr)
            det_prob = torch.sigmoid(det_logits).cpu().numpy()
            det_pred = (det_prob >= 0.5).astype(int)
            cls_pred = cls_logits.argmax(dim=1).cpu().numpy()
            bus_pred = bus_logits.argmax(dim=1).cpu().numpy()
        return {
            "detection": det_pred,
            "detection_prob": det_prob,
            "classification": cls_pred,
            "classification_prob": F.softmax(cls_logits, dim=1).cpu().numpy(),
            "localization_bus": bus_pred,
            "localization_bus_prob": F.softmax(bus_logits, dim=1).cpu().numpy(),
        }

    def count_parameters(self) -> int:
        return sum(p.numel() for p in self.parameters() if p.requires_grad)


def _build_edge_index(pmu_buses: tuple[int, ...] = OBSERVED_PMUS) -> torch.Tensor:
    """Build bidirectional edge index connecting all PMU nodes."""
    n = len(pmu_buses)
    edges = []
    for i in range(n):
        for j in range(n):
            if i != j:
                edges.append([i, j])
    return torch.tensor(edges, dtype=torch.long).t().contiguous()


def _load_distance_matrix(topology_dir: Path = DEFAULT_TOPOLOGY_DIR) -> np.ndarray:
    dist_path = topology_dir / "zbus_effective_distance_full.csv"
    if not dist_path.exists():
        return np.ones((39, 39))
    dist_df = pd.read_csv(dist_path)
    matrix = np.ones((39, 39))
    for _, row in dist_df.iterrows():
        i, j = int(row["from_bus"]) - 1, int(row["to_bus"]) - 1
        val = max(float(row["z_eff_abs"]), 1e-6)
        matrix[i, j] = val
        matrix[j, i] = val
    return matrix


def _build_edge_attr(pmu_buses: tuple[int, ...] = OBSERVED_PMUS, topology_dir: Path = DEFAULT_TOPOLOGY_DIR) -> torch.Tensor:
    """Build edge attributes from Zbus electrical distances."""
    dist_matrix = _load_distance_matrix(topology_dir)
    n = len(pmu_buses)
    edge_attr = []
    for i in range(n):
        for j in range(n):
            if i != j:
                bus_i = pmu_buses[i] - 1
                bus_j = pmu_buses[j] - 1
                inv_dist = 1.0 / max(dist_matrix[bus_i, bus_j], 1e-6)
                edge_attr.append([inv_dist])
    return torch.tensor(edge_attr, dtype=torch.float)


def build_ieee39_graph(pmu_buses: tuple[int, ...] = OBSERVED_PMUS, topology_dir: Path = DEFAULT_TOPOLOGY_DIR) -> tuple[torch.Tensor, torch.Tensor]:
    """Build the 8-PMU graph with edge index and Zbus-based edge weights."""
    edge_index = _build_edge_index(pmu_buses)
    edge_attr = _build_edge_attr(pmu_buses, topology_dir)
    return edge_index, edge_attr
