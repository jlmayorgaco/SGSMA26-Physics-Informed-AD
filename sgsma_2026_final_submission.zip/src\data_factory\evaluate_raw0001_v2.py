from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import joblib
import numpy as np
import pandas as pd
from sklearn.metrics import accuracy_score, classification_report, confusion_matrix, f1_score, recall_score

from src.data_factory.feature_extractor_v2 import extract_window_features_v2
from src.data_factory.train_hierarchical_pipeline import _json_safe, _location_type, _prefix_features, _positive_proba
from src.data_factory.train_hierarchical_pipeline_v2 import (
    DEFAULT_OUT,
    _feature_matrix,
    _has_missing,
    _predict_hierarchical,
    _predict_locations,
)


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_RAW_DIR = ROOT / "data" / "RAW0001"
DEFAULT_TIMELINE = ROOT / "data" / "event_profiles" / "raw0001_event_timeline.csv"
RAW_BUSES = (2, 5, 6, 10, 19, 22, 29, 39)


def _official_label(row: pd.Series) -> int:
    signature = str(row.get("event_signature", ""))
    event_code = int(row["event_code"])
    if "+6" in signature or "6(" in signature:
        return 6
    return event_code


def _official_location(row: pd.Series) -> str:
    event_code = _official_label(row)
    if event_code == 0:
        return "none"
    if event_code == 2:
        return "LINE23-24"
    if event_code in {1, 3, 4}:
        target = str(row.get("target_location", "")).strip()
        if target.startswith("Bus"):
            return target.upper()
        if target:
            return target.upper()
    if event_code in {5, 7}:
        active = str(row.get("active_buses", "")).split("|")[0].strip()
        if active.startswith("Bus"):
            return "PMU" + active.replace("Bus", "")
    if event_code == 6:
        return "BUS2"
    return "none"


def _load_raw_frames(raw_dir: Path) -> dict[int, pd.DataFrame]:
    frames = {}
    for bus in RAW_BUSES:
        path = raw_dir / f"Bus{bus}_Competition_Data_nanmask.csv"
        frames[bus] = pd.read_csv(path)
    return frames


def _window_bounds(row: pd.Series, global_start: float, global_end: float, context_seconds: float) -> tuple[float, float] | None:
    event_code = int(row["event_code"])
    start = float(row["start_time"])
    end = float(row["end_time"])
    duration = float(row["duration_seconds"])
    if event_code == 0:
        if duration < context_seconds:
            return None
        window_start = start
    else:
        window_start = max(global_start, start - 3.0)
    window_end = min(global_end, window_start + context_seconds)
    if window_end - window_start < 5.0:
        return None
    return float(window_start), float(window_end)


def build_raw_context_features(
    raw_dir: Path = DEFAULT_RAW_DIR,
    timeline_csv: Path = DEFAULT_TIMELINE,
    context_seconds: float = 30.0,
) -> tuple[pd.DataFrame, list[str]]:
    frames = _load_raw_frames(raw_dir)
    timeline = pd.read_csv(timeline_csv)
    global_start = min(float(frame["TIMESTAMP"].min()) for frame in frames.values())
    global_end = max(float(frame["TIMESTAMP"].max()) for frame in frames.values())
    rows: list[dict[str, Any]] = []
    skipped: list[str] = []
    for _, event_row in timeline.iterrows():
        bounds = _window_bounds(event_row, global_start, global_end, context_seconds)
        if bounds is None:
            skipped.append(str(event_row["chunk_name"]))
            continue
        window_start, window_end = bounds
        row: dict[str, Any] = {
            "chunk_name": str(event_row["chunk_name"]),
            "true_event": _official_label(event_row),
            "true_abnormal": int(_official_label(event_row) != 0),
            "event_signature": str(event_row.get("event_signature", "")),
            "target_location": str(event_row.get("target_location", "")),
            "true_location": _official_location(event_row),
            "window_start": window_start,
            "window_end": window_end,
        }
        bus_feature_rows = []
        for bus, frame in sorted(frames.items()):
            mask = (frame["TIMESTAMP"] >= window_start) & (frame["TIMESTAMP"] <= window_end)
            segment = frame.loc[mask].copy()
            if segment.empty:
                continue
            segment["TIMESTAMP"] = segment["TIMESTAMP"] - window_start
            features = extract_window_features_v2(segment)
            row.update(_prefix_features(features, f"BUS{bus}"))
            bus_feature_rows.append(features)
        if bus_feature_rows:
            numeric = pd.DataFrame(bus_feature_rows).select_dtypes(include=[np.number])
            for col in numeric.columns:
                row[f"GLOBAL__{col}__mean"] = float(numeric[col].mean())
                row[f"GLOBAL__{col}__max"] = float(numeric[col].max())
                row[f"GLOBAL__{col}__min"] = float(numeric[col].min())
                row[f"GLOBAL__{col}__std"] = float(numeric[col].std(ddof=0))
        rows.append(row)
    data = pd.DataFrame(rows)
    data.attrs["skipped_windows"] = skipped
    return data, skipped


def evaluate_raw0001(
    model_dir: Path = DEFAULT_OUT,
    raw_dir: Path = DEFAULT_RAW_DIR,
    timeline_csv: Path = DEFAULT_TIMELINE,
    out_dir: Path | None = None,
    context_seconds: float = 30.0,
) -> dict[str, Any]:
    if out_dir is None:
        out_dir = model_dir / "raw0001_eval"
    out_dir.mkdir(parents=True, exist_ok=True)
    data, skipped = build_raw_context_features(raw_dir, timeline_csv, context_seconds)
    feature_cols = json.loads((model_dir / "feature_columns.json").read_text(encoding="utf-8"))
    x = data.reindex(columns=feature_cols, fill_value=np.nan)
    physical_model = joblib.load(model_dir / "physical_event_classifier.joblib")
    bad_data_model = joblib.load(model_dir / "bad_data_detector.joblib")
    missing_model = joblib.load(model_dir / "missing_composition_detector.joblib")
    localizers = joblib.load(model_dir / "typed_localizers.joblib")
    config = json.loads((model_dir / "hierarchical_model_config.json").read_text(encoding="utf-8"))
    thresholds = {
        "bad_data_probability": float(config["bad_data_probability"]),
        "missing_composition_probability": float(config["missing_composition_probability"]),
        "missing_physical_confidence": float(config.get("missing_physical_confidence", 0.0)),
    }
    pred_event, pred_physical, bad_score, physical_confidence = _predict_hierarchical(
        x,
        data,
        physical_model,
        bad_data_model,
        missing_model,
        thresholds["bad_data_probability"],
        thresholds["missing_composition_probability"],
        thresholds["missing_physical_confidence"],
    )
    pred_location = _predict_locations(x, pred_event, pred_physical, localizers)
    missing_mask = _has_missing(data)
    missing_score = np.zeros(len(data), dtype=float)
    if missing_mask.any():
        missing_score[missing_mask] = _positive_proba(missing_model, x.loc[missing_mask])

    compact = data[
        [
            "chunk_name",
            "true_event",
            "true_abnormal",
            "event_signature",
            "target_location",
            "true_location",
            "window_start",
            "window_end",
        ]
    ].copy()
    compact["pred_event"] = pred_event
    compact["pred_physical_event"] = pred_physical
    compact["pred_abnormal"] = (pred_event != 0).astype(int)
    compact["missing_detected"] = missing_mask.astype(int)
    compact["bad_data_probability"] = bad_score
    compact["missing_composition_probability"] = missing_score
    compact["physical_confidence"] = physical_confidence
    compact["pred_location"] = pred_location
    compact["location_exact"] = compact["true_location"].eq(compact["pred_location"]).astype(int)
    compact.to_csv(out_dir / "raw0001_30s_context_predictions_v2.csv", index=False)
    data.to_csv(out_dir / "raw0001_30s_context_features_v2.csv", index=False)

    labels = list(range(9))
    y_true = compact["true_event"].to_numpy(dtype=int)
    y_pred = compact["pred_event"].to_numpy(dtype=int)
    loc_mask = compact["true_location"].ne("none")
    report = {
        "n_windows": int(len(compact)),
        "skipped_windows": skipped,
        "thresholds": thresholds,
        "accuracy": float(accuracy_score(y_true, y_pred)),
        "macro_f1": float(f1_score(y_true, y_pred, labels=labels, average="macro", zero_division=0)),
        "weighted_f1": float(f1_score(y_true, y_pred, labels=labels, average="weighted", zero_division=0)),
        "confusion_matrix": confusion_matrix(y_true, y_pred, labels=labels).tolist(),
        "labels": labels,
        "classification_report": classification_report(y_true, y_pred, labels=labels, output_dict=True, zero_division=0),
        "detector_accuracy": float(accuracy_score(compact["true_abnormal"], compact["pred_abnormal"])),
        "detector_recall_abnormal": float(recall_score(compact["true_abnormal"], compact["pred_abnormal"], pos_label=1)),
        "detector_confusion_matrix": confusion_matrix(compact["true_abnormal"], compact["pred_abnormal"], labels=[0, 1]).tolist(),
        "location": {
            "evaluated_windows": int(loc_mask.sum()),
            "exact_accuracy": float(compact.loc[loc_mask, "location_exact"].mean()) if loc_mask.any() else 0.0,
            "type_confusion_matrix": confusion_matrix(
                compact.loc[loc_mask, "true_location"].map(_location_type),
                compact.loc[loc_mask, "pred_location"].map(_location_type),
                labels=["BUS", "LINE", "PMU"],
            ).tolist()
            if loc_mask.any()
            else [],
        },
    }
    (out_dir / "raw0001_30s_context_eval_report_v2.json").write_text(json.dumps(_json_safe(report), indent=2), encoding="utf-8")
    return report


def main() -> None:
    parser = argparse.ArgumentParser(description="Evaluate stable v2 hierarchical model on RAW0001 timeline windows.")
    parser.add_argument("--model-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--raw-dir", type=Path, default=DEFAULT_RAW_DIR)
    parser.add_argument("--timeline-csv", type=Path, default=DEFAULT_TIMELINE)
    parser.add_argument("--out-dir", type=Path)
    parser.add_argument("--context-seconds", type=float, default=30.0)
    args = parser.parse_args()
    report = evaluate_raw0001(args.model_dir, args.raw_dir, args.timeline_csv, args.out_dir, args.context_seconds)
    print(json.dumps(_json_safe(report), indent=2))


if __name__ == "__main__":
    main()
