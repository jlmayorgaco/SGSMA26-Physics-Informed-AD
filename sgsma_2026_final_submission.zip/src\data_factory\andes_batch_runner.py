from __future__ import annotations

import argparse
import json
import math
from concurrent.futures import ProcessPoolExecutor, as_completed
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path
from typing import Any

import matplotlib

matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

from src.utils.io import json_safe as _shared_json_safe


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_SCENARIO_DIR = ROOT / "data" / "scenarios" / "sgsma_2026_v1"
DEFAULT_TOPOLOGY_DIR = ROOT / "data" / "topology" / "ieee39"
DEFAULT_OUT = ROOT / "data" / "simulated" / "sgsma_2026_factory_v1"
DEFAULT_CHUNKED = ROOT / "data" / "chunked"
DEFAULT_RAW_DIR = ROOT / "data" / "RAW0001"
DEFAULT_TIMELINE = ROOT / "data" / "event_profiles" / "raw0001_event_timeline.csv"
SIGNALS = (
    "VA_ANG",
    "VA_MAG",
    "VB_ANG",
    "VB_MAG",
    "VC_ANG",
    "VC_MAG",
    "IA_ANG",
    "IA_MAG",
    "IB_ANG",
    "IB_MAG",
    "IC_ANG",
    "IC_MAG",
    "Freq",
    "ROCOF",
)
PHASE_OFFSETS = {"A": 0.0, "B": -120.0, "C": 120.0}


@dataclass(frozen=True, slots=True)
class RunnerConfig:
    scenario_dir: Path = DEFAULT_SCENARIO_DIR
    topology_dir: Path = DEFAULT_TOPOLOGY_DIR
    out_dir: Path = DEFAULT_OUT
    max_scenarios: int | None = None
    overwrite: bool = False
    make_plots: bool = True
    include_hidden: bool = True
    raw_profile: bool = True
    progress_every: int = 1
    workers: int = 1


def _json_safe(value: Any) -> Any:
    return _shared_json_safe(value)


def _load_distances(topology_dir: Path) -> pd.DataFrame:
    path = topology_dir / "zbus_effective_distance_full.csv"
    if not path.exists():
        raise FileNotFoundError(f"Missing topology distance file: {path}")
    return pd.read_csv(path)


def _distance_weight(distances: pd.DataFrame, source_bus: int, target_buses: tuple[int, ...]) -> dict[int, float]:
    rows = distances[distances["from_bus"].astype(int).eq(int(source_bus))]
    raw: dict[int, float] = {}
    for bus in target_buses:
        match = rows[rows["to_bus"].astype(int).eq(int(bus))]
        if match.empty:
            raw[int(bus)] = 0.0
            continue
        z = float(match.iloc[0]["z_eff_abs"])
        raw[int(bus)] = 1.0 / max(z, 1e-6)
    max_value = max(raw.values()) if raw else 1.0
    return {bus: float(value / max_value) for bus, value in raw.items()}


def _line_weight(distances: pd.DataFrame, line_from: int, line_to: int, target_buses: tuple[int, ...]) -> dict[int, float]:
    w1 = _distance_weight(distances, line_from, target_buses)
    w2 = _distance_weight(distances, line_to, target_buses)
    return {bus: max(w1.get(bus, 0.0), w2.get(bus, 0.0)) for bus in target_buses}


def _smooth_step(t: np.ndarray, t0: float, tau: float = 0.20) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-(t - t0) / tau))


def _pulse(t: np.ndarray, t0: float, duration: float, tau: float = 0.04) -> np.ndarray:
    return _smooth_step(t, t0, tau=tau) - _smooth_step(t, t0 + duration, tau=tau)


def _robust_abs_scale(values: np.ndarray, fallback: float = 1.0) -> float:
    finite = values[np.isfinite(values)]
    if len(finite) == 0:
        return fallback
    scale = float(np.nanmedian(np.abs(finite)))
    if not math.isfinite(scale) or scale < 1e-9:
        return fallback
    return scale


def _magnitude_scales(frame: pd.DataFrame, bus: int) -> tuple[float, float]:
    v_cols = [f"BUS{bus}_V{phase}_MAG" for phase in PHASE_OFFSETS if f"BUS{bus}_V{phase}_MAG" in frame]
    i_cols = [f"BUS{bus}_I{phase}_MAG" for phase in PHASE_OFFSETS if f"BUS{bus}_I{phase}_MAG" in frame]
    v_scale = _robust_abs_scale(frame[v_cols].to_numpy(dtype=float).ravel(), fallback=1.0) if v_cols else 1.0
    i_scale = _robust_abs_scale(frame[i_cols].to_numpy(dtype=float).ravel(), fallback=1.0) if i_cols else 1.0
    return v_scale, i_scale


def _bad_data_delta(frame: pd.DataFrame, column: str, severity: float) -> float:
    values = pd.to_numeric(frame[column], errors="coerce").to_numpy(dtype=float)
    finite = values[np.isfinite(values)]
    if len(finite) == 0:
        return severity
    median_abs = max(float(np.nanmedian(np.abs(finite))), 1e-9)
    diffs = np.diff(finite)
    mad = float(np.nanmedian(np.abs(diffs - np.nanmedian(diffs)))) if len(diffs) else 0.0
    if column.endswith("_MAG"):
        # RAW-profiled voltage/current magnitudes are in engineering units, so
        # an absolute +2 value can be invisible. Make bad data a visible but
        # still local sensor perturbation.
        local_scale = max(12.0 * mad, 0.035 * median_abs)
        return severity * local_scale
    if column.endswith("_ANG"):
        return 1.75 * severity
    if column.endswith("_Freq"):
        return 0.02 * severity
    if column.endswith("_ROCOF"):
        return 0.05 * severity
    return severity


def _base_frame(bus: int, t: np.ndarray) -> pd.DataFrame:
    # Deterministic pre-event operating point. The factory trains on deltas and
    # zero-centered windows, so exact absolute levels are intentionally modest.
    rng = np.random.default_rng(10_000 + int(bus))
    v0 = 1.0 + rng.normal(0.0, 0.012)
    i0 = 1.0 + rng.normal(0.0, 0.08)
    angle0 = rng.uniform(-18.0, 18.0)
    drift = rng.normal(-8.0, 1.5)
    theta = angle0 + drift * t
    frame = pd.DataFrame({"TIMESTAMP": t})
    for phase, offset in PHASE_OFFSETS.items():
        frame[f"BUS{bus}_V{phase}_ANG"] = theta + offset
        frame[f"BUS{bus}_V{phase}_MAG"] = v0
        frame[f"BUS{bus}_I{phase}_ANG"] = theta - 25.0 + offset
        frame[f"BUS{bus}_I{phase}_MAG"] = i0
    frame[f"BUS{bus}_Freq"] = 60.0 + drift / 360.0
    frame[f"BUS{bus}_ROCOF"] = 0.0
    frame["DATA_PRESENT"] = 1
    frame["Event"] = 0
    return frame


@lru_cache(maxsize=16)
def _read_raw_bus_frame(raw_dir: str, bus: int) -> pd.DataFrame | None:
    path = Path(raw_dir) / f"Bus{bus}_Competition_Data_nanmask.csv"
    if not path.exists():
        return None
    try:
        return pd.read_csv(path)
    except Exception:
        return None


@lru_cache(maxsize=4)
def _read_timeline(timeline_csv: str) -> pd.DataFrame | None:
    path = Path(timeline_csv)
    if not path.exists():
        return None
    try:
        return pd.read_csv(path)
    except Exception:
        return None


def _raw_profile_slice(raw: pd.DataFrame, t: np.ndarray, scenario: dict[str, Any]) -> pd.DataFrame:
    n = len(t)
    profile = scenario.get("raw_profile") or {}
    timeline = _read_timeline(str(DEFAULT_TIMELINE))
    chunk = str(profile.get("event0_chunk") or "")
    if timeline is not None and "chunk_name" in timeline and chunk:
        match = timeline[timeline["chunk_name"].astype(str).eq(chunk)]
        if not match.empty:
            row = match.iloc[0]
            start_time = float(row.get("start_time", raw["TIMESTAMP"].min()))
            duration = max(float(row.get("duration_seconds", 30.0)), t[-1] - t[0])
            max_offset = max(0.0, duration - (t[-1] - t[0]))
            start_fraction = float(profile.get("start_fraction") or 0.0)
            start_time += max_offset * min(max(start_fraction, 0.0), 1.0)
            mask = raw["TIMESTAMP"].between(start_time, start_time + (t[-1] - t[0]) + 1e-9)
            sample = raw.loc[mask].head(n).reset_index(drop=True)
            if len(sample) >= 3:
                return sample

    start_fraction = float(profile.get("start_fraction") or 0.0)
    max_start = max(0, len(raw) - n)
    start = int(round(max_start * min(max(start_fraction, 0.0), 1.0)))
    return raw.iloc[start : start + n].reset_index(drop=True).copy()


def _raw_profile_frame(bus: int, t: np.ndarray, scenario: dict[str, Any]) -> pd.DataFrame | None:
    profile = scenario.get("raw_profile") or {}
    if not bool(profile.get("enabled", False)):
        return None
    chunk = str(profile.get("event0_chunk") or "")
    path = DEFAULT_CHUNKED / chunk / f"Bus{bus}_Competition_Data_nanmask.csv"
    if path.exists():
        try:
            raw = pd.read_csv(path)
        except Exception:
            raw = None
    else:
        raw = _read_raw_bus_frame(str(DEFAULT_RAW_DIR), int(bus))
    if raw is None:
        return None
    if len(raw) < 3:
        return None
    n = len(t)
    sample = raw.iloc[:n].reset_index(drop=True).copy() if path.exists() else _raw_profile_slice(raw, t, scenario)
    if len(sample) < n:
        sample = pd.concat([sample, raw.tail(1).loc[raw.tail(1).index.repeat(n - len(sample))]], ignore_index=True)
    out = pd.DataFrame({"TIMESTAMP": t})
    for signal in SIGNALS:
        col = f"BUS{bus}_{signal}"
        if col in sample:
            vals = pd.to_numeric(sample[col], errors="coerce").to_numpy(dtype=float)[:n]
            if signal.endswith("_ANG"):
                vals = np.rad2deg(np.unwrap(np.deg2rad(vals)))
            out[col] = vals
    required = [f"BUS{bus}_{signal}" for signal in SIGNALS]
    if not all(col in out for col in required):
        return None
    out["DATA_PRESENT"] = 1
    out["Event"] = 0
    return out


def _apply_physical_event(frame: pd.DataFrame, bus: int, event: dict[str, Any], weight: float) -> None:
    t = frame["TIMESTAMP"].to_numpy(dtype=float)
    event_type = str(event["type"])
    t0 = float(event["t_start"])
    v_scale, i_scale = _magnitude_scales(frame, bus)
    if event_type == "event1":
        shape = _pulse(t, t0, float(event.get("duration") or 0.12), tau=0.03)
        dv = -0.35 * weight * shape
        di = 1.10 * weight * shape
        dang = -8.0 * weight * shape
    elif event_type == "event2":
        shape = _smooth_step(t, t0, tau=0.20)
        dv = -0.025 * weight * shape
        di = 0.35 * weight * shape
        dang = 2.5 * weight * shape
    elif event_type == "event3":
        amount = float(event.get("amount") or 0.08)
        shape = _smooth_step(t, t0, tau=0.60)
        dv = 0.015 * np.sign(amount) * weight * shape
        di = -0.18 * amount * weight * shape
        dang = 4.0 * amount * weight * shape
        frame[f"BUS{bus}_Freq"] += 0.10 * amount * weight * shape
    elif event_type == "event4":
        amount = float(event.get("amount") or 0.10)
        shape = _smooth_step(t, t0, tau=0.35)
        dv = -0.045 * amount * weight * shape
        di = 0.55 * amount * weight * shape
        dang = -1.8 * amount * weight * shape
        frame[f"BUS{bus}_Freq"] += -0.015 * amount * weight * shape
    elif event_type == "event8":
        shape = _pulse(t, t0, float(event.get("duration") or 1.0), tau=0.12)
        severity = float(event.get("severity") or 1.0)
        dv = 0.018 * severity * weight * np.sin(2.0 * np.pi * 0.7 * np.maximum(t - t0, 0.0)) * shape
        di = 0.12 * severity * weight * shape
        dang = 1.5 * severity * weight * shape
    else:
        return

    for phase in PHASE_OFFSETS:
        frame[f"BUS{bus}_V{phase}_MAG"] += dv * v_scale
        frame[f"BUS{bus}_I{phase}_MAG"] += di * i_scale
        frame[f"BUS{bus}_V{phase}_ANG"] += dang
        frame[f"BUS{bus}_I{phase}_ANG"] += dang * 1.25
    frame["Event"] = int(event_type.replace("event", "")) if event_type != "event6" else 6


def _apply_cyber_event(frame: pd.DataFrame, bus: int, event: dict[str, Any]) -> None:
    target = event.get("pmu_target")
    if target is not None and int(target) != int(bus):
        return
    t = frame["TIMESTAMP"].to_numpy(dtype=float)
    mask = (t >= float(event["t_start"])) & (t <= float(event["t_start"]) + float(event.get("duration") or 0.5))
    event_type = str(event["type"])
    if event_type == "event5":
        signal_cols = [col for col in frame.columns if col.startswith(f"BUS{bus}_")]
        frame.loc[mask, signal_cols] = np.nan
        frame.loc[mask, "DATA_PRESENT"] = 0
        frame.loc[mask, "Event"] = 5
    elif event_type == "event7":
        signal = str(event.get("signal_target") or "VA_MAG")
        col = f"BUS{bus}_{signal}"
        if col in frame:
            delta = _bad_data_delta(frame, col, float(event.get("severity") or 4.0))
            frame.loc[mask, col] = frame.loc[mask, col] + delta
        frame.loc[mask, "Event"] = 7
    elif event_type == "event8":
        target = event.get("pmu_target")
        if target is None or int(target) == int(bus):
            signal = str(event.get("signal_target") or "Freq")
            col = f"BUS{bus}_{signal}"
            if col in frame:
                delta = _bad_data_delta(frame, col, float(event.get("severity") or 1.0))
                frame.loc[mask, col] = frame.loc[mask, col] + delta
            frame.loc[mask, "Event"] = 8


def _finalize_frequency(frame: pd.DataFrame, bus: int) -> None:
    t = frame["TIMESTAMP"].to_numpy(dtype=float)
    dt = float(np.nanmedian(np.diff(t))) if len(t) > 1 else 1.0 / 30.0
    theta = np.deg2rad(frame[f"BUS{bus}_VA_ANG"].to_numpy(dtype=float))
    theta = np.unwrap(theta)
    freq = 60.0 + np.gradient(theta, dt) / (2.0 * np.pi)
    rocof = np.gradient(freq, dt)
    frame[f"BUS{bus}_Freq"] = freq
    frame[f"BUS{bus}_ROCOF"] = rocof
    for phase in PHASE_OFFSETS:
        for prefix in ("V", "I"):
            col = f"BUS{bus}_{prefix}{phase}_ANG"
            frame[col] = np.rad2deg(np.unwrap(np.deg2rad(frame[col].to_numpy(dtype=float))))


def _all_topology_buses(distances: pd.DataFrame) -> tuple[int, ...]:
    values = set(pd.to_numeric(distances["from_bus"], errors="coerce").dropna().astype(int).tolist())
    values.update(pd.to_numeric(distances["to_bus"], errors="coerce").dropna().astype(int).tolist())
    return tuple(sorted(values))


def simulate_scenario(
    scenario: dict[str, Any],
    distances: pd.DataFrame,
    include_hidden: bool = True,
    raw_profile: bool = True,
) -> dict[int, pd.DataFrame]:
    observed = tuple(int(x) for x in scenario["observed_pmus"])
    target_buses = _all_topology_buses(distances) if include_hidden else observed
    duration = float(scenario.get("duration_s", 30.0))
    dt = float(scenario.get("dt_s", 1.0 / 30.0))
    t = np.arange(0.0, duration + dt * 0.5, dt)
    frames: dict[int, pd.DataFrame] = {}
    for bus in target_buses:
        profiled = _raw_profile_frame(bus, t, scenario) if raw_profile and bus in observed else None
        frames[bus] = profiled if profiled is not None else _base_frame(bus, t)
    for event in scenario["events"]:
        event_type = str(event["type"])
        if event_type in {"event1", "event3", "event4"}:
            source = int(event["bus_target"])
            weights = _distance_weight(distances, source, target_buses)
            for bus, frame in frames.items():
                _apply_physical_event(frame, bus, event, weights[bus])
        elif event_type == "event2":
            weights = _line_weight(distances, int(event["line_from"]), int(event["line_to"]), target_buses)
            for bus, frame in frames.items():
                _apply_physical_event(frame, bus, event, weights[bus])
        elif event_type == "event8":
            source = int(event.get("bus_target") or observed[0])
            weights = _distance_weight(distances, source, target_buses)
            for bus, frame in frames.items():
                _apply_physical_event(frame, bus, event, weights[bus])
                _apply_cyber_event(frame, bus, event)
        elif event_type in {"event5", "event7"}:
            for bus, frame in frames.items():
                _apply_cyber_event(frame, bus, event)
    for bus, frame in frames.items():
        _finalize_frequency(frame, bus)
    return frames


def _plot_megaplot(sim_id: str, frames: dict[int, pd.DataFrame], out_path: Path) -> None:
    fig, axes = plt.subplots(7, 2, figsize=(20, 25), sharex=True)
    colors = plt.cm.tab10(np.linspace(0, 1, len(frames)))
    for ax, signal in zip(axes.ravel(), SIGNALS, strict=False):
        for color, (bus, frame) in zip(colors, sorted(frames.items()), strict=False):
            col = f"BUS{bus}_{signal}"
            if col not in frame:
                continue
            ax.plot(frame["TIMESTAMP"], pd.to_numeric(frame[col], errors="coerce"), linewidth=0.8, color=color, label=f"BUS{bus}")
        ax.set_title(signal)
        ax.grid(True, alpha=0.25)
    axes.ravel()[0].legend(ncol=4, fontsize=8)
    fig.suptitle(f"{sim_id} PMU megaplot", fontsize=16)
    fig.supxlabel("Time [s]")
    fig.tight_layout(rect=[0, 0.02, 1, 0.98])
    out_path.parent.mkdir(parents=True, exist_ok=True)
    fig.savefig(out_path, dpi=130)
    plt.close(fig)


def run_one(
    scenario_path: Path,
    distances: pd.DataFrame,
    out_dir: Path,
    overwrite: bool,
    make_plots: bool,
    include_hidden: bool,
    raw_profile: bool,
) -> dict[str, Any]:
    scenario = json.loads(scenario_path.read_text(encoding="utf-8"))
    sim_id = str(scenario["sim_id"])
    sim_dir = out_dir / sim_id
    pmu_dir = sim_dir / "pmu"
    nonpmu_dir = sim_dir / "nonpmu"
    plot_dir = sim_dir / "plots"
    manifest_path = sim_dir / "manifest.json"
    observed = tuple(int(x) for x in scenario["observed_pmus"])
    hidden = tuple(bus for bus in _all_topology_buses(distances) if bus not in set(observed))
    hidden_complete = (not include_hidden) or (
        nonpmu_dir.exists() and len(list(nonpmu_dir.glob("Bus*_Hidden_State_sim.csv"))) >= len(hidden)
    )
    if manifest_path.exists() and not overwrite and hidden_complete:
        return {"sim_id": sim_id, "status": "skipped", "manifest": str(manifest_path.resolve())}
    pmu_dir.mkdir(parents=True, exist_ok=True)
    if include_hidden:
        nonpmu_dir.mkdir(parents=True, exist_ok=True)
    frames = simulate_scenario(scenario, distances, include_hidden=include_hidden, raw_profile=raw_profile)
    for bus, frame in frames.items():
        if bus in observed:
            frame.to_csv(pmu_dir / f"Bus{bus}_Competition_Data_sim.csv", index=False)
        elif include_hidden:
            frame.to_csv(nonpmu_dir / f"Bus{bus}_Hidden_State_sim.csv", index=False)
    plot_path = plot_dir / f"{sim_id}_megaplot.png"
    if make_plots:
        _plot_megaplot(sim_id, {bus: frames[bus] for bus in observed}, plot_path)
    manifest = {
        "sim_id": sim_id,
        "scenario_json": str(scenario_path.resolve()),
        "backend": "fast_physics_topology_surrogate_v1",
        "raw_profile_enabled": bool(raw_profile),
        "pmu_dir": str(pmu_dir.resolve()),
        "nonpmu_dir": str(nonpmu_dir.resolve()) if include_hidden else None,
        "observed_pmus": list(observed),
        "hidden_buses": list(hidden) if include_hidden else [],
        "plot": str(plot_path.resolve()) if make_plots else None,
        "events": scenario["events"],
        "status": "completed",
    }
    manifest_path.write_text(json.dumps(_json_safe(manifest), indent=2), encoding="utf-8")
    return {"sim_id": sim_id, "status": "completed", "manifest": str(manifest_path.resolve())}


def run_batch(config: RunnerConfig) -> dict[str, Any]:
    distances = _load_distances(config.topology_dir)
    paths = sorted(config.scenario_dir.glob("SIM*.json"))
    if config.max_scenarios is not None:
        paths = paths[: int(config.max_scenarios)]
    config.out_dir.mkdir(parents=True, exist_ok=True)
    rows = []
    if int(config.workers) <= 1:
        for idx, path in enumerate(paths, start=1):
            result = run_one(path, distances, config.out_dir, config.overwrite, config.make_plots, config.include_hidden, config.raw_profile)
            rows.append(result)
            if config.progress_every > 0 and (idx == 1 or idx == len(paths) or idx % config.progress_every == 0):
                print(f"{idx}/{len(paths)} {result['sim_id']} {result['status']}", flush=True)
    else:
        with ProcessPoolExecutor(max_workers=int(config.workers)) as pool:
            futures = [
                pool.submit(
                    run_one,
                    path,
                    distances,
                    config.out_dir,
                    config.overwrite,
                    config.make_plots,
                    config.include_hidden,
                    config.raw_profile,
                )
                for path in paths
            ]
            for idx, future in enumerate(as_completed(futures), start=1):
                result = future.result()
                rows.append(result)
                if config.progress_every > 0 and (idx == 1 or idx == len(paths) or idx % config.progress_every == 0):
                    print(f"{idx}/{len(paths)} {result['sim_id']} {result['status']}", flush=True)
    summary = {
        "backend": "fast_physics_topology_surrogate_v1",
        "scenario_dir": str(config.scenario_dir.resolve()),
        "topology_dir": str(config.topology_dir.resolve()),
        "out_dir": str(config.out_dir.resolve()),
        "requested": len(paths),
        "completed": sum(1 for row in rows if row["status"] == "completed"),
        "skipped": sum(1 for row in rows if row["status"] == "skipped"),
        "include_hidden": bool(config.include_hidden),
        "raw_profile": bool(config.raw_profile),
    }
    (config.out_dir / "batch_manifest.json").write_text(json.dumps(_json_safe(summary), indent=2), encoding="utf-8")
    pd.DataFrame(rows).to_csv(config.out_dir / "batch_index.csv", index=False)
    return summary


def main() -> None:
    parser = argparse.ArgumentParser(description="Run SGSMA scenario JSON files into PMU CSVs and megaplots.")
    parser.add_argument("--scenario-dir", type=Path, default=DEFAULT_SCENARIO_DIR)
    parser.add_argument("--topology-dir", type=Path, default=DEFAULT_TOPOLOGY_DIR)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    parser.add_argument("--max-scenarios", type=int, default=None)
    parser.add_argument("--overwrite", action="store_true")
    parser.add_argument("--no-plots", action="store_true")
    parser.add_argument("--no-hidden", action="store_true")
    parser.add_argument("--no-raw-profile", action="store_true")
    parser.add_argument("--progress-every", type=int, default=1)
    parser.add_argument("--workers", type=int, default=1)
    args = parser.parse_args()
    summary = run_batch(
        RunnerConfig(
            scenario_dir=args.scenario_dir,
            topology_dir=args.topology_dir,
            out_dir=args.out_dir,
            max_scenarios=args.max_scenarios,
            overwrite=bool(args.overwrite),
            make_plots=not bool(args.no_plots),
            include_hidden=not bool(args.no_hidden),
            raw_profile=not bool(args.no_raw_profile),
            progress_every=int(args.progress_every),
            workers=max(1, int(args.workers)),
        )
    )
    print(json.dumps(_json_safe(summary), indent=2))


if __name__ == "__main__":
    main()
