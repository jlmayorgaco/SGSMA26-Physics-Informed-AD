from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.helpers.power_network import (
    _build_full_ybus,
    _parse_branch_section_physical,
    _parse_raw_physical_bus_map,
)
from src.utils.io import json_safe as _shared_json_safe


ROOT = Path(__file__).resolve().parents[2]
DEFAULT_RAW = ROOT / "data" / "metadata" / "IEEE_39_Bus_Power_System.raw"
DEFAULT_CONTRACT = ROOT / "data" / "metadata" / "ieee39_competition_contract.json"
DEFAULT_OUT = ROOT / "data" / "topology" / "ieee39"


def _json_safe(value: Any) -> Any:
    return _shared_json_safe(value)


def _load_observed_pmus(contract_path: Path) -> list[int]:
    contract = json.loads(contract_path.read_text(encoding="utf-8"))
    return [int(row["physical_bus_number"]) for row in contract["pmu_map"]]


def _zbus_from_ybus(ybus: np.ndarray) -> np.ndarray:
    # Ybus is singular without a reference. The Moore-Penrose inverse gives an
    # effective impedance geometry usable for ML distances and localization.
    return np.linalg.pinv(ybus)


def _effective_impedance(zbus: np.ndarray) -> np.ndarray:
    diag = np.diag(zbus)
    return diag[:, None] + diag[None, :] - zbus - zbus.T


def _complex_matrix_frame(matrix: np.ndarray, buses: list[int]) -> pd.DataFrame:
    rows = []
    for i, bus_i in enumerate(buses):
        for j, bus_j in enumerate(buses):
            value = matrix[i, j]
            rows.append(
                {
                    "from_bus": int(bus_i),
                    "to_bus": int(bus_j),
                    "real": float(np.real(value)),
                    "imag": float(np.imag(value)),
                    "abs": float(abs(value)),
                    "angle_rad": float(np.angle(value)),
                }
            )
    return pd.DataFrame(rows)


def _distance_frame(effective_z: np.ndarray, buses: list[int]) -> pd.DataFrame:
    rows = []
    for i, bus_i in enumerate(buses):
        for j, bus_j in enumerate(buses):
            rows.append(
                {
                    "from_bus": int(bus_i),
                    "to_bus": int(bus_j),
                    "z_eff_abs": float(abs(effective_z[i, j])),
                    "z_eff_real": float(np.real(effective_z[i, j])),
                    "z_eff_imag": float(np.imag(effective_z[i, j])),
                }
            )
    return pd.DataFrame(rows)


def build_topology_bundle(
    raw_path: Path = DEFAULT_RAW,
    contract_path: Path = DEFAULT_CONTRACT,
    out_dir: Path = DEFAULT_OUT,
) -> dict[str, Any]:
    out_dir.mkdir(parents=True, exist_ok=True)
    physical_map = _parse_raw_physical_bus_map(raw_path)
    buses = sorted(set(int(value) for value in physical_map.values()))
    observed = _load_observed_pmus(contract_path)
    branches = _parse_branch_section_physical(raw_path)
    ybus = _build_full_ybus(bus_numbers=buses, branches=branches)
    zbus = _zbus_from_ybus(ybus)
    z_eff = _effective_impedance(zbus)

    ybus_path = out_dir / "ybus_full_complex.csv"
    zbus_path = out_dir / "zbus_full_complex.csv"
    dist_path = out_dir / "zbus_effective_distance_full.csv"
    observed_path = out_dir / "zbus_effective_distance_observed_pmus.csv"
    branch_path = out_dir / "branches_physical.csv"

    _complex_matrix_frame(ybus, buses).to_csv(ybus_path, index=False)
    _complex_matrix_frame(zbus, buses).to_csv(zbus_path, index=False)
    full_dist = _distance_frame(z_eff, buses)
    full_dist.to_csv(dist_path, index=False)
    full_dist[full_dist["from_bus"].isin(observed) & full_dist["to_bus"].isin(observed)].to_csv(observed_path, index=False)
    pd.DataFrame(
        [
            {
                "from_bus": branch.from_bus,
                "to_bus": branch.to_bus,
                "r": branch.resistance,
                "x": branch.reactance,
                "b": branch.charging,
                "tap": branch.tap,
                "shift_deg": branch.shift_deg,
            }
            for branch in branches
        ]
    ).to_csv(branch_path, index=False)

    manifest = {
        "schema_version": "sgsma-topology-v1",
        "source_raw": str(raw_path.resolve()),
        "backend": "native_psse_raw_parser",
        "note": "Zbus is computed as pinv(Ybus). Effective impedance distance is Zii + Zjj - Zij - Zji.",
        "n_buses": len(buses),
        "n_branches": len(branches),
        "observed_pmus": observed,
        "outputs": {
            "ybus_full_complex": str(ybus_path.resolve()),
            "zbus_full_complex": str(zbus_path.resolve()),
            "zbus_effective_distance_full": str(dist_path.resolve()),
            "zbus_effective_distance_observed_pmus": str(observed_path.resolve()),
            "branches_physical": str(branch_path.resolve()),
        },
    }
    (out_dir / "topology_manifest.json").write_text(json.dumps(_json_safe(manifest), indent=2), encoding="utf-8")
    return manifest


def main() -> None:
    parser = argparse.ArgumentParser(description="Extract IEEE39 Ybus/Zbus topology features.")
    parser.add_argument("--raw", type=Path, default=DEFAULT_RAW)
    parser.add_argument("--contract", type=Path, default=DEFAULT_CONTRACT)
    parser.add_argument("--out-dir", type=Path, default=DEFAULT_OUT)
    args = parser.parse_args()
    manifest = build_topology_bundle(raw_path=args.raw, contract_path=args.contract, out_dir=args.out_dir)
    print(json.dumps(_json_safe(manifest), indent=2))


if __name__ == "__main__":
    main()
