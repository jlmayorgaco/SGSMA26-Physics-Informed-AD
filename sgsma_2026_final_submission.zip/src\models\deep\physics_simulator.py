from __future__ import annotations

from pathlib import Path
from typing import Any

import numpy as np
import pandas as pd

from src.helpers.paths import ROOT

OBSERVED_PMUS = (2, 5, 6, 10, 19, 22, 29, 39)
N_BUSES = 39
PMU_NAMES = [f"BUS{bus}" for bus in OBSERVED_PMUS]
TOPOLOGY_DIR = ROOT / "data" / "topology" / "ieee39"
RAW_V2_CSV = ROOT / "workbench" / "raw_current_eval" / "raw001_base_features_v2.csv"


class FastPhysicsGenerator:
    """Vectorized physics-informed synthetic data generator.

    Generates PMU node features [N, 8, n_feat] using Zbus propagation weights,
    event-type templates extracted from REAL RAW001 data, and physics transformations.
    """

    def __init__(self, topology_dir: Path = TOPOLOGY_DIR, raw_csv: Path = RAW_V2_CSV):
        self.topology_dir = Path(topology_dir)
        self.dist_matrix = self._load_distance_matrix()
        self.lines = self._load_transmission_lines()
        self.line_labels = [f"LINE{a}-{b}" for a, b in self.lines]
        self.pmu_labels = [f"PMU{b}" for b in OBSERVED_PMUS]
        self.bus_labels = [f"BUS{b}" for b in range(1, 40)]

        self._load_templates(raw_csv)
        self._precompute_propagation()

    def _load_distance_matrix(self) -> np.ndarray:
        path = self.topology_dir / "zbus_effective_distance_full.csv"
        matrix = np.ones((39, 39)) * 10.0
        if path.exists():
            df = pd.read_csv(path)
            for _, row in df.iterrows():
                i, j = int(row["from_bus"]) - 1, int(row["to_bus"]) - 1
                matrix[i, j] = matrix[j, i] = max(float(row["z_eff_abs"]), 0.001)
        return matrix

    def _load_transmission_lines(self) -> list[tuple[int, int]]:
        path = self.topology_dir / "branches_physical.csv"
        lines = []
        if path.exists():
            df = pd.read_csv(path)
            for _, row in df.iterrows():
                a, b = int(row["from_bus"]), int(row["to_bus"])
                tap = float(row.get("tap", 1.0))
                shift = float(row.get("shift_deg", 0.0))
                if a <= 29 or b <= 29:
                    if abs(tap - 1.0) < 0.02 and abs(shift) < 1.0:
                        lines.append((min(a, b), max(a, b)))
        return sorted(set(lines))

    def _load_templates(self, raw_csv: Path):
        """Load per-PMU feature statistics from RAW001 data."""
        df = pd.read_csv(raw_csv)
        self.feat_dim = 0
        self.per_pmu_cols = {}
        for pmu in PMU_NAMES:
            cols = [c for c in df.columns if c.startswith(f"{pmu}__") and pd.api.types.is_numeric_dtype(df[c])]
            if cols:
                self.per_pmu_cols[pmu] = cols
                self.feat_dim = max(self.feat_dim, len(cols))

        # Extract feature templates per event type per PMU
        self.templates = {}
        for pmu in PMU_NAMES:
            if pmu not in self.per_pmu_cols:
                continue
            cols = self.per_pmu_cols[pmu][:self.feat_dim]
            self.templates[pmu] = {}
            for event_label in range(9):
                mask = df["true_event"].astype(int) == event_label
                if mask.any():
                    vals = df.loc[mask, cols].values.astype(np.float32)
                    self.templates[pmu][event_label] = {
                        "mean": np.nanmean(vals, axis=0),
                        "std": np.nanstd(vals, axis=0) + 1e-6,
                    }
            if 0 not in self.templates[pmu]:
                vals = df.loc[:, cols].values.astype(np.float32)
                self.templates[pmu][0] = {
                    "mean": np.nanmean(vals, axis=0),
                    "std": np.nanstd(vals, axis=0) + 1e-6,
                }

    def _precompute_propagation(self):
        """Pre-compute propagation weights from all buses to all PMUs."""
        self.bus_weights = np.zeros((39, 8), dtype=np.float32)
        for bus in range(1, 40):
            for j, pmu in enumerate(OBSERVED_PMUS):
                dist = self.dist_matrix[bus - 1, pmu - 1]
                self.bus_weights[bus - 1, j] = 1.0 / max(dist, 0.001)
        self.bus_weights /= (self.bus_weights.max(axis=1, keepdims=True) + 1e-9)

        self.line_weights = np.zeros((len(self.lines), 8), dtype=np.float32)
        for idx, (a, b) in enumerate(self.lines):
            wa = self.bus_weights[a - 1]
            wb = self.bus_weights[b - 1]
            self.line_weights[idx] = (wa + wb) / 2.0
        self.line_weights /= (self.line_weights.max(axis=1, keepdims=True) + 1e-9)

        self.pmu_weights = self.bus_weights[np.array(OBSERVED_PMUS) - 1]

    def _perturb_features(self, feat: np.ndarray, weights: np.ndarray, event_label: int, pmu_idx: int, rng: np.random.RandomState) -> np.ndarray:
        """Apply event-type-specific perturbation to a feature vector (vectorized)."""
        w = weights[pmu_idx]
        out = feat.copy()

        scale = 1.0 + w * rng.uniform(0.05, 0.4, size=out.shape).astype(np.float32)

        if event_label == 1:  # Fault: strong voltage changes
            scale *= (1.0 + w * rng.uniform(1.0, 10.0))
        elif event_label == 2:  # Line outage: moderate current changes
            scale *= (1.0 + w * rng.uniform(0.3, 3.0))
        elif event_label == 3:  # Gen change: frequency-domain changes
            scale *= (1.0 + w * rng.uniform(0.1, 2.0))
        elif event_label == 4:  # Load change: mild changes
            scale *= (1.0 + w * rng.uniform(0.05, 1.0))
        elif event_label in (5, 6):  # Missing: zero out affected PMU
            if w > 0.6:
                scale = np.zeros_like(scale)
        elif event_label == 7:  # Bad data: sparse large outliers
            if w > 0.5:
                outlier_mask = rng.random(len(out)) < 0.05
                scale[outlier_mask] = rng.uniform(50, 200, size=outlier_mask.sum())
        elif event_label == 8:  # Mixed: moderate random changes
            scale *= (1.0 + w * rng.uniform(0.5, 5.0))

        out *= scale
        return out.astype(np.float32)

    def generate_batch(self, n_samples: int, per_event_balance: dict[int, int] | None = None, rng: np.random.RandomState | None = None) -> dict[str, Any]:
        """Generate a batch of synthetic training data."""
        if rng is None:
            rng = np.random.RandomState(42)

        if per_event_balance is None:
            per_event_balance = {0: 100, 1: 100, 2: 100, 3: 80, 4: 80, 5: 60, 6: 60, 7: 60, 8: 60}

        n_total = sum(per_event_balance.values())
        all_features = np.zeros((n_total, 8, self.feat_dim), dtype=np.float32)
        all_det = np.zeros(n_total, dtype=np.int64)
        all_cls = np.zeros(n_total, dtype=np.int64)
        all_loc = np.empty(n_total, dtype=object)
        all_loctype = np.empty(n_total, dtype=object)

        pos = 0
        for event_label, count in sorted(per_event_balance.items()):
            for _ in range(count):
                # Pick location
                if event_label == 0:
                    loc = "none"
                    ltype = "NONE"
                elif event_label == 2:
                    loc = rng.choice(self.line_labels)
                    ltype = "LINE"
                elif event_label in (5,):
                    loc = rng.choice(self.pmu_labels)
                    ltype = "PMU"
                elif event_label in (7,):
                    loc = rng.choice(self.pmu_labels)
                    ltype = "PMU"
                else:
                    loc = rng.choice(self.bus_labels)
                    ltype = "BUS"

                # Get propagation weights
                if ltype == "BUS":
                    bus = int(loc.replace("BUS", ""))
                    weights = self.bus_weights[bus - 1]
                elif ltype == "LINE":
                    parts = loc.replace("LINE", "").split("-")
                    bus_a, bus_b = int(parts[0]), int(parts[1])
                    weights = (self.bus_weights[bus_a - 1] + self.bus_weights[bus_b - 1]) / 2
                    weights /= (weights.max() + 1e-9)
                elif ltype == "PMU":
                    bus = int(loc.replace("PMU", ""))
                    weights = self.bus_weights[bus - 1]
                else:
                    weights = np.ones(8, dtype=np.float32) * 0.5

                # Generate features per PMU
                for pmu_idx, pmu in enumerate(PMU_NAMES):
                    if pmu in self.templates and event_label in self.templates[pmu]:
                        t = self.templates[pmu][event_label]
                        feat = t["mean"] + rng.randn(self.feat_dim).astype(np.float32) * t["std"] * 0.1
                        feat = self._perturb_features(feat, weights, event_label, pmu_idx, rng)
                    elif pmu in self.templates and 0 in self.templates[pmu]:
                        t = self.templates[pmu][0]
                        feat = t["mean"] + rng.randn(self.feat_dim).astype(np.float32) * t["std"] * 0.1
                        feat = self._perturb_features(feat, weights, event_label, pmu_idx, rng)
                    else:
                        feat = np.random.randn(self.feat_dim).astype(np.float32) * 0.1
                    all_features[pos, pmu_idx] = feat

                all_det[pos] = 0 if event_label == 0 else 1
                all_cls[pos] = event_label
                all_loc[pos] = loc
                all_loctype[pos] = ltype
                pos += 1

        return {
            "features": all_features,
            "det_labels": all_det,
            "cls_labels": all_cls,
            "loc_labels": all_loc,
            "loc_types": all_loctype,
            "n_samples": pos,
        }
